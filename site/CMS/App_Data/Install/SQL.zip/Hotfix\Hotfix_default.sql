-- HF9-51 Replacing wrong default statistics code name for daily exit page report
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 1
BEGIN

UPDATE [Reporting_Report] SET 
        [ReportParameters] = '<form version="2"><field column="FromDate" columntype="datetime" guid="c4fb5fa9-d4c9-4e2a-8729-5128296b5cd5" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime.AddMonths(-1).Date%}</defaultvalue><fieldcaption>{$general.from$}</fieldcaption></properties><settings><controlname>calendarcontrol</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="ToDate" columntype="datetime" guid="a003a89e-90e2-4325-8c6f-ea227a01939b" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime%}</defaultvalue><fieldcaption>{$general.to$}</fieldcaption></properties><settings><controlname>calendarcontrol</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="CodeName" columnsize="50" columntype="text" guid="65080419-ff4e-45db-bd16-947473425d6e" publicfield="false" reftype="Required" visibility="none"><properties><defaultvalue>exitpage</defaultvalue></properties><settings><controlname>dropdownlistcontrol</controlname><Query>SELECT DISTINCT StatisticsCode, StatisticsCode FROM Analytics_Statistics</Query></settings></field></form>'
    WHERE [ReportGUID] = 'b147a0d3-b309-4be8-b94d-77dd45a21288'

END
GO

-- HF9-50 - Remove test page templates
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 1
BEGIN
	DELETE FROM [CMS_PageTemplate]
	WHERE [PageTemplateGUID] IN (
		'C233553F-4DEC-4B51-A82A-47B3552CABC8',
		'F267096C-8192-46D4-8554-FD938AF405F4',
		'E1259A99-20BD-44D5-862E-29F98FB2A43F',
		'A99B808C-47C8-4338-9C00-ABAA8C77BD0F',
		'73F867CD-7790-404E-B606-AB12516F41F8',
		'1274ED06-D591-4760-ABF2-6DCAB721A5C1',
		'ECE89CFE-1700-4203-90CE-6803901A8A25',
		'D58963A4-32AA-4CAF-8269-A15A626CC176'
	)
END
GO

-- HF9-47 - DocumentNamePath inconsistency after recreating different
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 1
BEGIN
	declare @alterScript NVARCHAR(MAX)
	select @alterScript =
'ALTER PROCEDURE [Proc_CMS_Document_UpdateDocumentNamePath]
	 @NodeID int,
	 @DocumentID int,
	 @PrefixesXML nvarchar(max),
	 @DefaultCultureCode nvarchar(10),
	 @GenerateAliases bit,
	 @CurrentDate datetime2(7)
	AS
	BEGIN

	-- Get XML from the string representation
	DECLARE @Prefixes xml = CAST(@PrefixesXML as XML);

	-- Prepare temp table for the results
	DECLARE @Documents TABLE
	(
	  NodeID int, 
	  DocumentID int, 
	  OriginalNamePrefix nvarchar(1500), 
	  NamePrefix nvarchar(1500), 
	  OriginalUrlPrefix nvarchar(450), 
	  UrlPrefix nvarchar(450)
	);

	WITH 
	Prefixes AS
	(
		SELECT 
			ref.value(''Culture[1]'', ''nvarchar(10)'') AS DocumentCulture, 
			ref.value(''(NamePath/Original)[1]'', ''nvarchar(1500)'') AS OriginalNamePrefix, 
			ref.value(''(NamePath/Current)[1]'', ''nvarchar(1500)'') AS NamePrefix, 
			ref.value(''(UrlPath/Original)[1]'', ''nvarchar(450)'') AS OriginalUrlPrefix, 
			ref.value(''(UrlPath/Current)[1]'', ''nvarchar(450)'') AS UrlPrefix 
		FROM @Prefixes.nodes(''/Prefixes/Prefix'') xmlData(ref)
	),
	Base AS
	(
		SELECT DocumentID, NodeID, NodeLinkedNodeID, TopDocumentCulture, OriginalNamePrefix, NamePrefix, OriginalUrlPrefix, UrlPrefix 
		FROM
		(
			SELECT 
				V.DocumentID, V.NodeID, V.NodeLinkedNodeID,
				V.DocumentCulture AS TopDocumentCulture,
				OriginalNamePrefix, NamePrefix, OriginalUrlPrefix, UrlPrefix,
				-- Prefer parent data in culture of the document, than in default culture, any other culture at least 
				ROW_NUMBER() OVER (PARTITION BY V.DocumentID, V.NodeID ORDER BY CASE WHEN P.DocumentCulture = V.DocumentCulture THEN 1 WHEN P.DocumentCulture = @DefaultCultureCode THEN 2 ELSE 3 END, P.DocumentCulture) AS CMS_C
	 		FROM View_CMS_Tree_Joined AS V WITH (NOLOCK)
					-- Get original and current prefix
					INNER JOIN Prefixes ON V.DocumentCulture = Prefixes.DocumentCulture
					-- Get parent values
					INNER JOIN View_CMS_Tree_Joined as P WITH (NOLOCK) ON (SELECT NodeParentID FROM CMS_Tree AS T WITH (NOLOCK) WHERE T.NodeID = V.NodeOriginalNodeID) = P.NodeID
			-- Get either all culture versions or just the one based on DocumentID
			WHERE (@NodeID <> 0 AND V.NodeOriginalNodeID = @NodeID) OR (@DocumentID <> 0 AND V.DocumentID = @DocumentID)
		) AS B
		-- Get data with best matching parent data
		WHERE CMS_C = 1
	),
	Candidates AS
	(
		SELECT * FROM Base

		UNION ALL

		SELECT DocumentID, NodeID, NodeLinkedNodeID, TopDocumentCulture, OriginalNamePrefix, NamePrefix, OriginalUrlPrefix, UrlPrefix FROM
		(
			SELECT 
				V.DocumentID, V.NodeID, V.NodeLinkedNodeID, 
				Candidates.TopDocumentCulture, Candidates.DocumentID AS CandidatesParentDocumentID,
				P.DocumentID AS ParentDocumentID,
				Prefixes.OriginalNamePrefix, Prefixes.NamePrefix, Prefixes.OriginalUrlPrefix, Prefixes.UrlPrefix,
				-- Prefer parent data in culture of the document, than in default culture, any other culture at least 
				ROW_NUMBER() OVER (PARTITION BY V.DocumentID, V.NodeID ORDER BY CASE WHEN P.DocumentCulture = V.DocumentCulture THEN 1 WHEN P.DocumentCulture = @DefaultCultureCode THEN 2 ELSE 3 END, P.DocumentCulture) AS CMS_C
			FROM Candidates
				-- Get original and current prefix
				INNER JOIN Prefixes ON Candidates.TopDocumentCulture = Prefixes.DocumentCulture
				-- Get all child documents (for links get the originals) of the current one having the original prefix
				INNER JOIN View_CMS_Tree_Joined V WITH (NOLOCK) ON (SELECT NodeParentID FROM CMS_Tree AS T WHERE T.NodeID = V.NodeOriginalNodeID) = Candidates.NodeID AND V.DocumentNamePath LIKE Prefixes.OriginalNamePrefix + ''%''
				-- Get all combinations with their parents
				INNER JOIN View_CMS_Tree_Joined as P WITH (NOLOCK) ON (SELECT NodeParentID FROM CMS_Tree AS T WHERE T.NodeID = V.NodeOriginalNodeID) = P.NodeID
		) AS LevelCandidates
		-- Include only those whose primary parents are included in the current scope
		WHERE CandidatesParentDocumentID = ParentDocumentID AND LevelCandidates.CMS_C = 1 AND LevelCandidates.DocumentID NOT IN (SELECT DocumentID FROM Base)
	),
	Items AS
	(
		-- Filter links since the originals are incldued as well
		SELECT DISTINCT NodeID, DocumentID, OriginalNamePrefix, NamePrefix, OriginalUrlPrefix, UrlPrefix 
		FROM Candidates
		WHERE NodeLinkedNodeID IS NULL
	)

	-- Get the final result set
	INSERT INTO @Documents SELECT NodeID, DocumentID, OriginalNamePrefix, NamePrefix, OriginalUrlPrefix, UrlPrefix FROM Items

	-- Generate document aliases
	IF (@GenerateAliases = 1)
	BEGIN
		-- Insert alias for all child documents where original URL path differs from the new one and the alias with same URL path doesn''t exist
		INSERT INTO CMS_DocumentAlias 
		(
			AliasNodeID, 
			AliasCulture, 
			AliasURLPath, 
			AliasExtensions, 
			AliasWildcardRule, 
			AliasPriority, 
			AliasGUID, 
			AliasLastModified, 
			AliasSiteID
		)
		SELECT 
			D.NodeID AS AliasNodeID, 
			DocumentCulture AS AliasCulture, 
			DocumentURLPath AS AliasURLPath, 
			'''' AS AliasExtensions, 
			'''' AS AliasWildcardRule, 
			1 AS AliasPriority, 
			NEWID() AS AliasGUID, 
			@CurrentDate AS AliasLastModified, 
			NodeSiteID AS AliasSiteID
		FROM @Documents AS D INNER JOIN View_CMS_Tree_Joined AS V ON D.DocumentID = V.DocumentID
		WHERE 
			-- Aliases were already generated for updated culture version
			-- Do not include links since the aliases are same as for originals included in the results
			D.DocumentID <> @DocumentID  AND NodeLinkedNodeID IS NULL
			-- Do not generate aliases for content-only pages
			AND NodeIsContentOnly = 0
			-- URL path is generated and differs from the original one
			AND DocumentUrlPath <> 
				(
				CASE WHEN DocumentUseNamePathForUrlPath = 1 AND (ISNULL(DocumentUrlPath, '''') <> '''')
				THEN
					-- Path starts with original URL path prefix
					CASE WHEN LEFT(DocumentUrlPath, LEN(OriginalUrlPrefix)) = OriginalUrlPrefix 
					THEN
						-- Replace original URL prefix with new URL path prefix
						UrlPrefix + SUBSTRING(DocumentUrlPath, LEN(OriginalUrlPrefix) + 1, LEN(DocumentUrlPath)) 
					-- Path starts with original name path prefix
					WHEN LEFT(DocumentUrlPath, LEN(OriginalNamePrefix)) = OriginalNamePrefix 
					THEN
						-- Replace original Name prefix with new URL path prefix (when new document is created, DocumentNamePath of the parent is used to build the URL path)
						UrlPrefix + SUBSTRING(DocumentUrlPath, LEN(OriginalNamePrefix) + 1, LEN(DocumentUrlPath)) 
					END
			  	ELSE DocumentUrlPath END
				)
			-- There is no alias with the same URL path
			AND NOT EXISTS (SELECT AliasID FROM CMS_DocumentAlias WHERE AliasURLPath = DocumentUrlPath AND AliasNodeID = D.NodeID AND (AliasCulture = DocumentCulture OR ISNULL(AliasCulture, '''') = ''''))
	END

	-- Propagate new prefixes to all child documents
	-- Currently modified document is not udpated since the paths were already udpated by API
	UPDATE CMS_Document SET
	DocumentNamePath = 
		(
		-- Path starts with original name prefix
		CASE WHEN LEFT(DocumentNamePath, LEN(OriginalNamePrefix)) = OriginalNamePrefix
		THEN
			NamePrefix + SUBSTRING(DocumentNamePath, LEN(OriginalNamePrefix) + 1, LEN(DocumentNamePath))
		ELSE DocumentNamePath END
		),
	DocumentUrlPath = 
		(
		CASE WHEN DocumentUseNamePathForUrlPath = 1 AND (ISNULL(DocumentUrlPath, '''') <> '''')
		THEN
			-- Path starts with original URL path prefix
			CASE WHEN LEFT(DocumentUrlPath, LEN(OriginalUrlPrefix)) = OriginalUrlPrefix 
			THEN
				-- Replace original URL prefix with new URL path prefix
				UrlPrefix + SUBSTRING(DocumentUrlPath, LEN(OriginalUrlPrefix) + 1, LEN(DocumentUrlPath)) 
			-- Path starts with original name path prefix
			WHEN LEFT(DocumentUrlPath, LEN(OriginalNamePrefix)) = OriginalNamePrefix 
			THEN
				-- Replace original Name prefix with new URL path prefix (when new document is created, DocumentNamePath of the parent is used to build the URL path)
				UrlPrefix + SUBSTRING(DocumentUrlPath, LEN(OriginalNamePrefix) + 1, LEN(DocumentUrlPath)) 
			END
		ELSE DocumentUrlPath END
		)
    FROM CMS_Document AS D INNER JOIN @Documents AS R ON D.DocumentID = R.DocumentID
	WHERE R.DocumentID <> @DocumentID

	END';

	exec(@alterScript)
END
GO


-- HF9-24 Update reports default properties to correct values
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 1
BEGIN

DECLARE @reportCategoryID int;
SET @reportCategoryID = (SELECT TOP 1 [CategoryID] FROM [Reporting_ReportCategory] WHERE [CategoryGUID] = '0521d2b1-6b4a-47eb-bc6d-c8f9540f7c7c')
IF @reportCategoryID IS NOT NULL BEGIN

UPDATE [Reporting_Report] SET 
        [ReportParameters] = '<form version="2"><field column="FromDate" columnprecision="7" columntype="datetime" guid="3a2bc443-7e96-4929-8f85-d09e0d4e47d3" publicfield="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime.AddMonths(-1).Date%}</defaultvalue><fieldcaption>{$general.from$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="ToDate" columnprecision="7" columntype="datetime" guid="ed1cb074-89d2-4576-a6c8-f451121f5269" publicfield="false" reftype="Required" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime%}</defaultvalue><fieldcaption>{$general.to$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="CodeName" columnsize="50" columntype="text" guid="ac0084c9-b77f-4711-8bea-0465c2346d1d" publicfield="false" visibility="none"><properties><defaultvalue>java</defaultvalue></properties></field></form>'
    WHERE [ReportGUID] = '2c996cda-9dd3-4817-afaa-caa9b89e2c03'

UPDATE [Reporting_Report] SET 
        [ReportParameters] = '<form version="2"><field column="FromDate" columnprecision="7" columntype="datetime" guid="3a2bc443-7e96-4929-8f85-d09e0d4e47d3" publicfield="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime.AddDays(-1)%}</defaultvalue><fieldcaption>{$general.from$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>True</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="ToDate" columnprecision="7" columntype="datetime" guid="ed1cb074-89d2-4576-a6c8-f451121f5269" publicfield="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime%}</defaultvalue><fieldcaption>{$general.to$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>True</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="CodeName" columnsize="50" columntype="text" guid="ac0084c9-b77f-4711-8bea-0465c2346d1d" publicfield="false" visibility="none"><properties><defaultvalue>java</defaultvalue></properties></field></form>'
    WHERE [ReportGUID] = 'fe248a73-bea3-4709-91be-638dd8f516a1'

UPDATE [Reporting_Report] SET 
        [ReportParameters] = '<form version="2"><field column="FromDate" columnprecision="7" columntype="datetime" guid="3a2bc443-7e96-4929-8f85-d09e0d4e47d3" publicfield="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime.AddYears(-1).Date%}</defaultvalue><fieldcaption>{$general.from$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="ToDate" columntype="date" guid="ed1cb074-89d2-4576-a6c8-f451121f5269" publicfield="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime%}</defaultvalue><fieldcaption>{$general.to$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="CodeName" columnsize="50" columntype="text" guid="ac0084c9-b77f-4711-8bea-0465c2346d1d" publicfield="false" visibility="none"><properties><defaultvalue>java</defaultvalue></properties></field></form>'
    WHERE [ReportGUID] = 'c61fbe1f-77a9-402f-94a7-cbcafe87e635'

UPDATE [Reporting_Report] SET 
        [ReportParameters] = '<form version="2"><field column="FromDate" columnprecision="7" columntype="datetime" guid="3a2bc443-7e96-4929-8f85-d09e0d4e47d3" publicfield="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime.AddWeeks(-15).Date%}</defaultvalue><fieldcaption>{$general.from$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="ToDate" columnprecision="7" columntype="datetime" guid="ed1cb074-89d2-4576-a6c8-f451121f5269" publicfield="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime%}</defaultvalue><fieldcaption>{$general.to$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="CodeName" columnsize="50" columntype="text" guid="ac0084c9-b77f-4711-8bea-0465c2346d1d" publicfield="false" visibility="none"><properties><defaultvalue>java</defaultvalue></properties></field></form>'
    WHERE [ReportGUID] = '61dc4d4a-b81c-49c7-9944-b56235abdcc3'

UPDATE [Reporting_Report] SET 
        [ReportParameters] = '<form version="2"><field column="FromDate" columnprecision="7" columntype="datetime" guid="3a2bc443-7e96-4929-8f85-d09e0d4e47d3" publicfield="false" reftype="Required" spellcheck="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime.AddYears(-6).Date%}</defaultvalue><fieldcaption>{$general.from$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="ToDate" columntype="datetime" guid="ed1cb074-89d2-4576-a6c8-f451121f5269" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime%}</defaultvalue><fieldcaption>{$general.to$}</fieldcaption></properties><settings><controlname>calendarcontrol</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="CodeName" columnsize="50" columntype="text" guid="ac0084c9-b77f-4711-8bea-0465c2346d1d" publicfield="false" visibility="none"><properties><defaultvalue>java</defaultvalue></properties></field></form>'
    WHERE [ReportGUID] = '0afebb85-80bf-4790-aeea-b55203d34217'

END

SET @reportCategoryID = (SELECT TOP 1 [CategoryID] FROM [Reporting_ReportCategory] WHERE [CategoryGUID] = '1d197150-65da-44ea-9dab-473e445fabd8')
IF @reportCategoryID IS NOT NULL BEGIN

UPDATE [Reporting_Report] SET 
        [ReportParameters] = '<form version="2"><field column="FromDate" columnprecision="7" columntype="datetime" guid="3a2bc443-7e96-4929-8f85-d09e0d4e47d3" publicfield="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime.AddMonths(-1).Date%}</defaultvalue><fieldcaption>{$general.from$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="ToDate" columnprecision="7" columntype="datetime" guid="ed1cb074-89d2-4576-a6c8-f451121f5269" publicfield="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime%}</defaultvalue><fieldcaption>{$general.to$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="CodeName" columnsize="50" columntype="text" guid="ac0084c9-b77f-4711-8bea-0465c2346d1d" publicfield="false" reftype="Required" visibility="none"><properties><defaultvalue>screenresolution</defaultvalue></properties></field></form>'
    WHERE [ReportGUID] = '410cdbd5-ad0b-4cf6-81fc-f9ff0683361c'

UPDATE [Reporting_Report] SET 
        [ReportParameters] = '<form version="2"><field column="FromDate" columnprecision="7" columntype="datetime" guid="3a2bc443-7e96-4929-8f85-d09e0d4e47d3" publicfield="false" reftype="Required" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime.AddDays(-1)%}</defaultvalue><fieldcaption>{$general.from$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>True</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="ToDate" columnprecision="7" columntype="datetime" guid="ed1cb074-89d2-4576-a6c8-f451121f5269" publicfield="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime%}</defaultvalue><fieldcaption>{$general.to$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>True</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="CodeName" columnsize="50" columntype="text" guid="ac0084c9-b77f-4711-8bea-0465c2346d1d" publicfield="false" visibility="none"><properties><defaultvalue>screenresolution</defaultvalue></properties></field></form>'
    WHERE [ReportGUID] = '7fcf03e2-1b74-4a6a-8287-b4c0323d8e34'

UPDATE [Reporting_Report] SET 
        [ReportParameters] = '<form version="2"><field column="FromDate" columnprecision="7" columntype="datetime" guid="3a2bc443-7e96-4929-8f85-d09e0d4e47d3" publicfield="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime.AddYears(-1).Date%}</defaultvalue><fieldcaption>{$general.from$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="ToDate" columnprecision="7" columntype="datetime" guid="ed1cb074-89d2-4576-a6c8-f451121f5269" publicfield="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime%}</defaultvalue><fieldcaption>{$general.to$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="CodeName" columnsize="50" columntype="text" guid="ac0084c9-b77f-4711-8bea-0465c2346d1d" publicfield="false" visibility="none"><properties><defaultvalue>screenresolution</defaultvalue></properties></field></form>'
    WHERE [ReportGUID] = 'a49ae785-9d9f-4bb7-b901-dda143686d62'

UPDATE [Reporting_Report] SET 
        [ReportParameters] = '<form version="2"><field column="FromDate" columnprecision="7" columntype="datetime" guid="3a2bc443-7e96-4929-8f85-d09e0d4e47d3" publicfield="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime.AddWeeks(-15).Date%}</defaultvalue><fieldcaption>{$general.from$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="ToDate" columnprecision="7" columntype="datetime" guid="ed1cb074-89d2-4576-a6c8-f451121f5269" publicfield="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime%}</defaultvalue><fieldcaption>{$general.to$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="CodeName" columnsize="50" columntype="text" guid="ac0084c9-b77f-4711-8bea-0465c2346d1d" publicfield="false" visibility="none"><properties><defaultvalue>screenresolution</defaultvalue></properties></field></form>'
    WHERE [ReportGUID] = '28343399-8990-4475-a82d-820651e02302'

END

SET @reportCategoryID = (SELECT TOP 1 [CategoryID] FROM [Reporting_ReportCategory] WHERE [CategoryGUID] = '4522b3bf-43a9-4b69-a542-2fcd2d188724')
IF @reportCategoryID IS NOT NULL BEGIN

UPDATE [Reporting_Report] SET 
        [ReportDisplayName] = 'Screen colors - Daily report', 
        [ReportParameters] = '<form version="2"><field column="FromDate" columnprecision="7" columntype="datetime" guid="3a2bc443-7e96-4929-8f85-d09e0d4e47d3" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime.AddMonths(-1).Date%}</defaultvalue><fieldcaption>{$general.from$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="ToDate" columnprecision="7" columntype="datetime" guid="ed1cb074-89d2-4576-a6c8-f451121f5269" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime%}</defaultvalue><fieldcaption>{$general.to$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="CodeName" columnsize="50" columntype="text" guid="ac0084c9-b77f-4711-8bea-0465c2346d1d" publicfield="false" reftype="Required" visibility="none"><properties><defaultvalue>screencolor</defaultvalue></properties></field></form>', 
        [ReportConnectionString] = ''
    WHERE [ReportGUID] = '0aca6cd2-5adb-4a8c-9f11-7aa9d990401b'

UPDATE [Reporting_Report] SET 
        [ReportDisplayName] = 'Screen colors - Hourly report', 
        [ReportParameters] = '<form version="2"><field column="FromDate" columnprecision="7" columntype="datetime" guid="3a2bc443-7e96-4929-8f85-d09e0d4e47d3" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime.AddDays(-1)%}</defaultvalue><fieldcaption>{$general.from$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>True</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="ToDate" columntype="datetime" guid="ed1cb074-89d2-4576-a6c8-f451121f5269" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime%}</defaultvalue><fieldcaption>{$general.to$}</fieldcaption></properties><settings><controlname>calendarcontrol</controlname><DisplayNow>True</DisplayNow><EditTime>True</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="CodeName" columnsize="50" columntype="text" guid="ac0084c9-b77f-4711-8bea-0465c2346d1d" publicfield="false" reftype="Required" visibility="none"><properties><defaultvalue>screencolor</defaultvalue></properties></field></form>', 
        [ReportConnectionString] = ''
    WHERE [ReportGUID] = '02a3cc26-2357-4cad-b2bc-493c99d434fe'

UPDATE [Reporting_Report] SET 
        [ReportParameters] = '<form version="2"><field column="FromDate" columnprecision="7" columntype="datetime" guid="3a2bc443-7e96-4929-8f85-d09e0d4e47d3" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime.AddYears(-1).Date%}</defaultvalue><fieldcaption>{$general.from$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="ToDate" columnprecision="7" columntype="datetime" guid="ed1cb074-89d2-4576-a6c8-f451121f5269" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime%}</defaultvalue><fieldcaption>{$general.to$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="CodeName" columnsize="50" columntype="text" guid="ac0084c9-b77f-4711-8bea-0465c2346d1d" publicfield="false" reftype="Required" visibility="none"><properties><defaultvalue>screencolor</defaultvalue></properties></field></form>'
    WHERE [ReportGUID] = '3c75bfb6-06d3-4509-85ca-cb54d397f1ec'

UPDATE [Reporting_Report] SET 
        [ReportParameters] = '<form version="2"><field column="FromDate" columnprecision="7" columntype="datetime" guid="3a2bc443-7e96-4929-8f85-d09e0d4e47d3" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime.AddWeeks(-15).Date%}</defaultvalue><fieldcaption>{$general.from$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="ToDate" columnprecision="7" columntype="datetime" guid="ed1cb074-89d2-4576-a6c8-f451121f5269" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime%}</defaultvalue><fieldcaption>{$general.to$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="CodeName" columnsize="50" columntype="text" guid="ac0084c9-b77f-4711-8bea-0465c2346d1d" publicfield="false" reftype="Required" visibility="none"><properties><defaultvalue>screencolor</defaultvalue></properties></field></form>'
    WHERE [ReportGUID] = 'c17c8152-b4bb-4c4f-ad99-80d03a55c276'

UPDATE [Reporting_Report] SET 
        [ReportParameters] = '<form version="2"><field column="FromDate" columntype="datetime" guid="3a2bc443-7e96-4929-8f85-d09e0d4e47d3" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime.AddYears(-6).Date%}</defaultvalue><fieldcaption>{$general.from$}</fieldcaption></properties><settings><controlname>calendarcontrol</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="ToDate" columntype="datetime" guid="ed1cb074-89d2-4576-a6c8-f451121f5269" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime%}</defaultvalue><fieldcaption>{$general.to$}</fieldcaption></properties><settings><controlname>calendarcontrol</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="CodeName" columnsize="50" columntype="text" guid="ac0084c9-b77f-4711-8bea-0465c2346d1d" publicfield="false" reftype="Required" visibility="none"><properties><defaultvalue>screencolor</defaultvalue></properties></field></form>'
    WHERE [ReportGUID] = '2d7d5375-f401-4993-b60b-8f1fee424bd7'

END

SET @reportCategoryID = (SELECT TOP 1 [CategoryID] FROM [Reporting_ReportCategory] WHERE [CategoryGUID] = '4cf57600-fef9-4e51-8cdc-f2b07429607a')
IF @reportCategoryID IS NOT NULL BEGIN

UPDATE [Reporting_Report] SET 
        [ReportDisplayName] = 'Operating system - Daily report', 
        [ReportParameters] = '<form version="2"><field column="FromDate" columnprecision="7" columntype="datetime" guid="3a2bc443-7e96-4929-8f85-d09e0d4e47d3" publicfield="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime.AddMonths(-1).Date%}</defaultvalue><fieldcaption>{$general.from$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="ToDate" columnprecision="7" columntype="datetime" guid="ed1cb074-89d2-4576-a6c8-f451121f5269" publicfield="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime%}</defaultvalue><fieldcaption>{$general.to$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="CodeName" columnsize="50" columntype="text" guid="ac0084c9-b77f-4711-8bea-0465c2346d1d" publicfield="false" visibility="none"><properties><defaultvalue>operatingsystem</defaultvalue></properties></field></form>', 
        [ReportConnectionString] = ''
    WHERE [ReportGUID] = 'e7a8e1ce-d320-4814-a470-b5c5ca7d1ca0'

UPDATE [Reporting_Report] SET 
        [ReportDisplayName] = 'Operating system - Hourly report', 
        [ReportParameters] = '<form version="2"><field column="FromDate" columnprecision="7" columntype="datetime" guid="3a2bc443-7e96-4929-8f85-d09e0d4e47d3" publicfield="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime.AddDays(-1)%}</defaultvalue><fieldcaption>{$general.from$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>True</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="ToDate" columnprecision="7" columntype="datetime" guid="ed1cb074-89d2-4576-a6c8-f451121f5269" publicfield="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime%}</defaultvalue><fieldcaption>{$general.to$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>True</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="CodeName" columnsize="50" columntype="text" guid="ac0084c9-b77f-4711-8bea-0465c2346d1d" publicfield="false" visibility="none"><properties><defaultvalue>operatingsystem</defaultvalue></properties></field></form>', 
        [ReportConnectionString] = ''
    WHERE [ReportGUID] = '3e1dd045-1dca-439a-b960-fec535974c17'

UPDATE [Reporting_Report] SET 
        [ReportParameters] = '<form version="2"><field column="FromDate" columnprecision="7" columntype="datetime" guid="3a2bc443-7e96-4929-8f85-d09e0d4e47d3" publicfield="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime.AddYears(-1).Date%}</defaultvalue><fieldcaption>{$general.from$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="ToDate" columnprecision="7" columntype="datetime" guid="ed1cb074-89d2-4576-a6c8-f451121f5269" publicfield="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime%}</defaultvalue><fieldcaption>{$general.to$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="CodeName" columnsize="50" columntype="text" guid="ac0084c9-b77f-4711-8bea-0465c2346d1d" publicfield="false" visibility="none"><properties><defaultvalue>operatingsystem</defaultvalue></properties></field></form>'
    WHERE [ReportGUID] = '2ad2d3af-0e74-4943-9cb5-9e6b873f8e0d'

UPDATE [Reporting_Report] SET 
        [ReportParameters] = '<form version="2"><field column="FromDate" columnprecision="7" columntype="datetime" guid="3a2bc443-7e96-4929-8f85-d09e0d4e47d3" publicfield="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime.AddWeeks(-15).Date%}</defaultvalue><fieldcaption>{$general.from$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="ToDate" columnprecision="7" columntype="datetime" guid="ed1cb074-89d2-4576-a6c8-f451121f5269" publicfield="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime%}</defaultvalue><fieldcaption>{$general.to$}</fieldcaption></properties><settings><CheckRange>True</CheckRange><controlname>CalendarControl</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="CodeName" columnsize="50" columntype="text" guid="ac0084c9-b77f-4711-8bea-0465c2346d1d" publicfield="false" visibility="none"><properties><defaultvalue>operatingsystem</defaultvalue></properties></field></form>'
    WHERE [ReportGUID] = '582744dc-d9fa-4492-a63f-cfc9a87db8ba'

END

SET @reportCategoryID = (SELECT TOP 1 [CategoryID] FROM [Reporting_ReportCategory] WHERE [CategoryGUID] = '6e36495b-2934-4118-bc0b-2fab27305a51')
IF @reportCategoryID IS NOT NULL BEGIN

UPDATE [Reporting_Report] SET 
        [ReportParameters] = '<form version="2"><field column="FromDate" columntype="datetime" guid="c4fb5fa9-d4c9-4e2a-8729-5128296b5cd5" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime.AddMonths(-1).Date%}</defaultvalue><fieldcaption>{$general.from$}</fieldcaption></properties><settings><controlname>calendarcontrol</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="ToDate" columntype="datetime" guid="a003a89e-90e2-4325-8c6f-ea227a01939b" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime%}</defaultvalue><fieldcaption>{$general.to$}</fieldcaption></properties><settings><controlname>calendarcontrol</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="CodeName" columnsize="50" columntype="text" guid="65080419-ff4e-45db-bd16-947473425d6e" publicfield="false" reftype="Required" visibility="none"><properties><defaultvalue>exitpage</defaultvalue></properties><settings><controlname>dropdownlistcontrol</controlname><Query>SELECT DISTINCT StatisticsCode, StatisticsCode FROM Analytics_Statistics</Query></settings></field></form>'
    WHERE [ReportGUID] = 'b147a0d3-b309-4be8-b94d-77dd45a21288'

END

END
GO


-- HF9-58 Update to obtain campaigns by its UTM code instead of the code name
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 1
BEGIN

DECLARE @tableReportID int;
SET @tableReportID = (SELECT TOP 1 [ReportID] FROM [Reporting_Report] WHERE [ReportGUID] = 'a4f498f3-bd0c-4470-bae1-1b9e07ed3e05')
IF @tableReportID IS NOT NULL BEGIN

UPDATE [Reporting_ReportTable] SET 
        [TableQuery] = 'SET @FromDate ={%DatabaseSchema%}.Func_Analytics_DateTrim(@FromDate,''day''); 
SET @ToDate ={%DatabaseSchema%}.Func_Analytics_EndDateTrim(@ToDate,''day''); 

IF (@ConversionName IS NULL OR @ConversionName = '''')
BEGIN

SELECT TOP 100 ConversionDisplayName AS ''{$reports_conversion.name_header$}'', SUM(HitsCount) AS
''{$reports_conversion.hits_header$}'',SUM(HitsValue) AS ''{$reports_conversion.value_header$}''  FROM
Analytics_Statistics 
JOIN Analytics_DayHits  ON HitsStatisticsID = StatisticsID
JOIN Analytics_Conversion ON ConversionName  = StatisticsObjectName AND ConversionSiteID = @CMSContextCurrentSiteID
WHERE (StatisticsSiteID = @CMSContextCurrentSiteID) AND
(StatisticsCode=N''conversion'') AND (StatisticsID = HitsStatisticsID) 
AND (@FromDate IS NULL OR @FromDate <= HitsStartTime) AND (@ToDate IS NULL OR @ToDate >= HitsStartTime)	
 GROUP BY ConversionDisplayName ORDER BY SUM(HitsCount) DESC
END

ELSE
BEGIN

SELECT
 ISNULL(CampaignDisplayName,''-'') AS ''{$campaign.campaign.list$}'',
 ISNULL(SUM(HitsCount),0) AS ''{$conversion.conversion.list$}'',
 ISNULL(SUM (HitsValue),0) AS ''{$conversions.value$}'',
 ISNULL(CAST (CAST (CAST (SUM(HitsCount) AS DECIMAL (15,2)) / Visits * 100 AS DECIMAL(15,1)) AS NVARCHAR(20))+''%'',''0.0%'') AS ''{$abtesting.conversionsrate$}'', 
 ISNULL(ROUND (SUM (HitsValue)  / NULLIF (Visits,0), 1),0) AS ''{$conversions.valuepervisit$}'',
 ISNULL(Visits,0) AS ''{$analytics_codename.visits$}''
 
FROM Analytics_Statistics JOIN Analytics_DayHits ON HitsStatisticsID = StatisticsID
LEFT JOIN 
(SELECT CampaignDisplayName,CampaignUTMCode,CampaignSiteID, SUM (HitsCount) AS Visits FROM Analytics_Campaign 
	LEFT JOIN Analytics_Statistics ON StatisticsCode = ''campaign'' AND StatisticsObjectName = CampaignUTMCode  AND CampaignSiteID = StatisticsSiteID 
	LEFT JOIN Analytics_DayHits ON HitsStatisticsID = StatisticsID
	WHERE CampaignSiteID = @CMSContextCurrentSiteID
	AND (@FromDate IS NULL OR @FromDate <= HitsStartTime) AND (@ToDate IS NULL OR @ToDate >= HitsStartTime)	
	GROUP BY CampaignDisplayName,CampaignUTMCode,CampaignSiteID)
 AS Campaigns 
ON Campaigns.CampaignUTMCode = SUBSTRING(StatisticsCode,16,LEN(StatisticsCode)) AND Campaigns.CampaignSiteID = StatisticsSiteID

WHERE StatisticsObjectName = @ConversionName AND StatisticsSiteID = @CMSContextCurrentSiteID AND 
(StatisticsCode=N''conversion'' OR StatisticsCode LIKE N''campconversion;%'')
AND (@FromDate IS NULL OR @FromDate <= HitsStartTime) AND (@ToDate IS NULL OR @ToDate >= HitsStartTime)	
GROUP BY CampaignDisplayName,Visits
ORDER BY SUM(HitsValue) DESC, CampaignDisplayName

END'
    WHERE [TableGUID] = 'f95992d3-ebeb-44c2-9b58-82a6523367ed'

END

END
GO

-- HF9-30 - Update webanalytics week country graph name and legend position
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 1
BEGIN
	UPDATE [Reporting_ReportGraph] SET 
        [GraphDisplayName] = 'graph',
		[GraphSettings] = '<customdata><displayitemvalue>True</displayitemvalue><legendtitle></legendtitle><yaxistitleposition>Center</yaxistitleposition><xaxislabelfont></xaxislabelfont><yaxislabelfont></yaxislabelfont><itemvalueformat>#PERCENT{P1} (#VALY)</itemvalueformat><seriessecbgcolor></seriessecbgcolor><legendbgcolor></legendbgcolor><xaxisinterval>1</xaxisinterval><xaxissort>True</xaxissort><yaxisusexaxissettings>True</yaxisusexaxissettings><reverseyaxis>False</reverseyaxis><legendposition>Right</legendposition><seriesitemlink></seriesitemlink><pieothervalue></pieothervalue><xaxisfont></xaxisfont><xaxistitleposition>Center</xaxistitleposition><xaxisformat></xaxisformat><yaxisfont></yaxisfont><querynorecordtext>No data found</querynorecordtext><plotareasecbgcolor></plotareasecbgcolor><seriesitemtooltip>#VALX  -   #PERCENT{P1}</seriesitemtooltip><rotatey></rotatey><stackedbarmaxstacked>False</stackedbarmaxstacked><scalemax></scalemax><titlefontnew></titlefontnew><exportenabled>True</exportenabled><subscriptionenabled>True</subscriptionenabled><plotareagradient>None</plotareagradient><titleposition>Center</titleposition><seriesgradient>None</seriesgradient><showmajorgrid>True</showmajorgrid><seriesprbgcolor></seriesprbgcolor><yaxisformat></yaxisformat><linedrawinstyle>Line</linedrawinstyle><tenpowers>False</tenpowers><plotareaprbgcolor></plotareaprbgcolor><valuesaspercent>False</valuesaspercent><rotatex></rotatex><legendinside>False</legendinside><xaxisangle></xaxisangle><showas3d>False</showas3d><baroverlay>False</baroverlay><yaxisangle></yaxisangle><scalemin></scalemin><barorientation>Vertical</barorientation></customdata>'
    WHERE [GraphGUID] = '263b6ed4-27fb-4626-a275-59d850b5ee9f'
END
GO

-- HF9-67 - DocumentNamePath inconsistency after recreating different
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 2
BEGIN
	declare @alterScript NVARCHAR(MAX)
	select @alterScript =
'ALTER PROCEDURE [Proc_CMS_Document_UpdateDocumentNamePath]
	 @NodeID int,
	 @DocumentID int,
	 @PrefixesXML nvarchar(max),
	 @DefaultCultureCode nvarchar(10),
	 @UpdateUrlPath bit,
	 @GenerateAliases bit,
	 @CurrentDate datetime2(7)
	AS
	BEGIN

	-- Get XML from the string representation
	DECLARE @Prefixes xml = CAST(@PrefixesXML as XML);

	-- Prepare temp table for the results
	DECLARE @Documents TABLE
	(
	  NodeID int, 
	  DocumentID int, 
	  OriginalNamePrefix nvarchar(1500), 
	  NamePrefix nvarchar(1500), 
	  OriginalUrlPrefix nvarchar(450), 
	  UrlPrefix nvarchar(450)
	);

	WITH 
	Prefixes AS
	(
		SELECT 
			ref.value(''Culture[1]'', ''nvarchar(10)'') AS DocumentCulture, 
			ref.value(''(NamePath/Original)[1]'', ''nvarchar(1500)'') AS OriginalNamePrefix, 
			ref.value(''(NamePath/Current)[1]'', ''nvarchar(1500)'') AS NamePrefix, 
			ref.value(''(UrlPath/Original)[1]'', ''nvarchar(450)'') AS OriginalUrlPrefix, 
			ref.value(''(UrlPath/Current)[1]'', ''nvarchar(450)'') AS UrlPrefix 
		FROM @Prefixes.nodes(''/Prefixes/Prefix'') xmlData(ref)
	),
	Base AS
	(
		SELECT DocumentID, NodeID, NodeLinkedNodeID, TopDocumentCulture, OriginalNamePrefix, NamePrefix, OriginalUrlPrefix, UrlPrefix 
		FROM
		(
			SELECT 
				V.DocumentID, V.NodeID, V.NodeLinkedNodeID,
				V.DocumentCulture AS TopDocumentCulture,
				OriginalNamePrefix, NamePrefix, OriginalUrlPrefix, UrlPrefix,
				-- Prefer parent data in culture of the document, than in default culture, any other culture at least 
				ROW_NUMBER() OVER (PARTITION BY V.DocumentID, V.NodeID ORDER BY CASE WHEN P.DocumentCulture = V.DocumentCulture THEN 1 WHEN P.DocumentCulture = @DefaultCultureCode THEN 2 ELSE 3 END, P.DocumentCulture) AS CMS_C
	 		FROM View_CMS_Tree_Joined AS V WITH (NOLOCK)
					-- Get original and current prefix
					INNER JOIN Prefixes ON V.DocumentCulture = Prefixes.DocumentCulture
					-- Get parent values
					INNER JOIN View_CMS_Tree_Joined as P WITH (NOLOCK) ON (SELECT NodeParentID FROM CMS_Tree AS T WITH (NOLOCK) WHERE T.NodeID = V.NodeOriginalNodeID) = P.NodeID
			-- Get either all culture versions or just the one based on DocumentID
			WHERE (@NodeID <> 0 AND V.NodeOriginalNodeID = @NodeID) OR (@DocumentID <> 0 AND V.DocumentID = @DocumentID)
		) AS B
		-- Get data with best matching parent data
		WHERE CMS_C = 1
	),
	Candidates AS
	(
		SELECT * FROM Base

		UNION ALL

		SELECT DocumentID, NodeID, NodeLinkedNodeID, TopDocumentCulture, OriginalNamePrefix, NamePrefix, OriginalUrlPrefix, UrlPrefix FROM
		(
			SELECT 
				V.DocumentID, V.NodeID, V.NodeLinkedNodeID, 
				Candidates.TopDocumentCulture, Candidates.DocumentID AS CandidatesParentDocumentID,
				P.DocumentID AS ParentDocumentID,
				Prefixes.OriginalNamePrefix, Prefixes.NamePrefix, Prefixes.OriginalUrlPrefix, Prefixes.UrlPrefix,
				-- Prefer parent data in culture of the document, than in default culture, any other culture at least 
				ROW_NUMBER() OVER (PARTITION BY V.DocumentID, V.NodeID ORDER BY CASE WHEN P.DocumentCulture = V.DocumentCulture THEN 1 WHEN P.DocumentCulture = @DefaultCultureCode THEN 2 ELSE 3 END, P.DocumentCulture) AS CMS_C
			FROM Candidates
				-- Get original and current prefix
				INNER JOIN Prefixes ON Candidates.TopDocumentCulture = Prefixes.DocumentCulture
				-- Get all child documents (for links get the originals) of the current one having the original prefix
				INNER JOIN View_CMS_Tree_Joined V WITH (NOLOCK) ON (SELECT NodeParentID FROM CMS_Tree AS T WHERE T.NodeID = V.NodeOriginalNodeID) = Candidates.NodeID AND V.DocumentNamePath LIKE Prefixes.OriginalNamePrefix + ''%''
				-- Get all combinations with their parents
				INNER JOIN View_CMS_Tree_Joined as P WITH (NOLOCK) ON (SELECT NodeParentID FROM CMS_Tree AS T WHERE T.NodeID = V.NodeOriginalNodeID) = P.NodeID
		) AS LevelCandidates
		-- Include only those whose primary parents are included in the current scope
		WHERE CandidatesParentDocumentID = ParentDocumentID AND LevelCandidates.CMS_C = 1 AND LevelCandidates.DocumentID NOT IN (SELECT DocumentID FROM Base)
	),
	Items AS
	(
		-- Filter links since the originals are incldued as well
		SELECT DISTINCT NodeID, DocumentID, OriginalNamePrefix, NamePrefix, OriginalUrlPrefix, UrlPrefix 
		FROM Candidates
		WHERE NodeLinkedNodeID IS NULL
	)

	-- Get the final result set
	INSERT INTO @Documents SELECT NodeID, DocumentID, OriginalNamePrefix, NamePrefix, OriginalUrlPrefix, UrlPrefix FROM Items

	-- Generate document aliases
	IF (@UpdateUrlPath = 1 AND @GenerateAliases = 1)
	BEGIN
		-- Insert alias for all child documents where original URL path differs from the new one and the alias with same URL path doesn''t exist
		INSERT INTO CMS_DocumentAlias 
		(
			AliasNodeID, 
			AliasCulture, 
			AliasURLPath, 
			AliasExtensions, 
			AliasWildcardRule, 
			AliasPriority, 
			AliasGUID, 
			AliasLastModified, 
			AliasSiteID
		)
		SELECT 
			D.NodeID AS AliasNodeID, 
			DocumentCulture AS AliasCulture, 
			DocumentURLPath AS AliasURLPath, 
			'''' AS AliasExtensions, 
			'''' AS AliasWildcardRule, 
			1 AS AliasPriority, 
			NEWID() AS AliasGUID, 
			@CurrentDate AS AliasLastModified, 
			NodeSiteID AS AliasSiteID
		FROM @Documents AS D INNER JOIN View_CMS_Tree_Joined AS V ON D.DocumentID = V.DocumentID
		WHERE 
			-- Aliases were already generated for updated culture version
			-- Do not include links since the aliases are same as for originals included in the results
			D.DocumentID <> @DocumentID  AND NodeLinkedNodeID IS NULL
			-- Do not generate aliases for content-only pages
			AND NodeIsContentOnly = 0
			-- URL path is generated and differs from the original one
			AND DocumentUrlPath <> 
				(
				CASE WHEN DocumentUseNamePathForUrlPath = 1 AND (ISNULL(DocumentUrlPath, '''') <> '''')
				THEN
					-- Path starts with original URL path prefix
					CASE WHEN LEFT(DocumentUrlPath, LEN(OriginalUrlPrefix)) = OriginalUrlPrefix 
					THEN
						-- Replace original URL prefix with new URL path prefix
						UrlPrefix + SUBSTRING(DocumentUrlPath, LEN(OriginalUrlPrefix) + 1, LEN(DocumentUrlPath)) 
					-- Path starts with original name path prefix
					WHEN LEFT(DocumentUrlPath, LEN(OriginalNamePrefix)) = OriginalNamePrefix 
					THEN
						-- Replace original Name prefix with new URL path prefix (when new document is created, DocumentNamePath of the parent is used to build the URL path)
						UrlPrefix + SUBSTRING(DocumentUrlPath, LEN(OriginalNamePrefix) + 1, LEN(DocumentUrlPath)) 
					ELSE
						DocumentUrlPath
					END
			  	ELSE DocumentUrlPath END
				)
			-- There is no alias with the same URL path
			AND NOT EXISTS (SELECT AliasID FROM CMS_DocumentAlias WHERE AliasURLPath = DocumentUrlPath AND AliasNodeID = D.NodeID AND (AliasCulture = DocumentCulture OR ISNULL(AliasCulture, '''') = ''''))
	END

	-- Propagate new prefixes to all child documents
	-- Currently modified document is not udpated since the paths were already udpated by API
	UPDATE CMS_Document SET
	DocumentNamePath = 
		(
		-- Path starts with original name prefix
		CASE WHEN LEFT(DocumentNamePath, LEN(OriginalNamePrefix)) = OriginalNamePrefix
		THEN
			NamePrefix + SUBSTRING(DocumentNamePath, LEN(OriginalNamePrefix) + 1, LEN(DocumentNamePath))
		ELSE DocumentNamePath END
		),
	DocumentUrlPath = 
		(
		CASE WHEN @UpdateUrlPath = 1 AND DocumentUseNamePathForUrlPath = 1 AND (ISNULL(DocumentUrlPath, '''') <> '''')
		THEN
			-- Path starts with original URL path prefix
			CASE WHEN LEFT(DocumentUrlPath, LEN(OriginalUrlPrefix)) = OriginalUrlPrefix 
			THEN
				-- Replace original URL prefix with new URL path prefix
				UrlPrefix + SUBSTRING(DocumentUrlPath, LEN(OriginalUrlPrefix) + 1, LEN(DocumentUrlPath)) 
			-- Path starts with original name path prefix
			WHEN LEFT(DocumentUrlPath, LEN(OriginalNamePrefix)) = OriginalNamePrefix 
			THEN
				-- Replace original Name prefix with new URL path prefix (when new document is created, DocumentNamePath of the parent is used to build the URL path)
				UrlPrefix + SUBSTRING(DocumentUrlPath, LEN(OriginalNamePrefix) + 1, LEN(DocumentUrlPath)) 
			ELSE
				DocumentUrlPath
			END
		ELSE DocumentUrlPath END
		)
    FROM CMS_Document AS D INNER JOIN @Documents AS R ON D.DocumentID = R.DocumentID
	WHERE R.DocumentID <> @DocumentID

	END';

	exec(@alterScript)
END
GO


-- HF9-73 - Hide A/B test field when license is lower than EMS
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 2
BEGIN

UPDATE [CMS_AlternativeForm]
  SET [FormDefinition] = '<form version="2"><field column="IssueID" isunique="true" visible="" /><field column="IssueVariantName" order="1"><settings><controlname>LabelControl</controlname><Transformation>#htmlencode</Transformation></settings><properties><fieldcaption>{$general.name$}</fieldcaption><visiblemacro ismacro="true">{%!String.IsNullOrEmpty(Value)%}</visiblemacro></properties></field><field column="IssueSubject" order="2"><settings><controlname>LabelControl</controlname><Transformation>#htmlencode</Transformation></settings><properties><fieldcaption>{$general.subject$}</fieldcaption></properties></field><field column="IssueStatus" columnprecision="" columnsize="" order="3"><settings><controlname>LabelControl</controlname><OutputFormat>{% GetResourceString("newsletterissuestatus." + ToStringRepresentation(Value, "CMS.Newsletters", "CMS.Newsletters.IssueStatusEnum"))%}</OutputFormat></settings><properties><fieldcaption>{$general.status$}</fieldcaption></properties></field><field column="IssueMailoutTime" order="4"><settings><controlname>LabelControl</controlname></settings><properties><fieldcaption>{$unigrid.newsletter_issue.columns.issuemailouttime$}</fieldcaption></properties></field><field column="IssueIsABTest" reftype="Required" order="5"><settings><controlname>LabelControl</controlname><Transformation>#yesno</Transformation></settings><properties><fieldcaption>{$newsletters.isabtest$}</fieldcaption><visiblemacro ismacro="true">{%LicenseHelper.CheckFeature(FeatureEnum.CampaignAndConversions)%}</visiblemacro></properties></field><field column="IssueSenderName" order="6"><settings><controlname>LabelControl</controlname><Transformation>#htmlencode</Transformation></settings><properties><fieldcaption>{$newsletterissue.sender.name$}</fieldcaption></properties></field><field column="IssueSenderEmail" order="7"><settings><controlname>LabelControl</controlname><Transformation>#htmlencode</Transformation></settings><properties><fieldcaption>{$newsletterissue.sender.email$}</fieldcaption></properties></field><field column="IssueUTMSource" order="8"><settings><controlname>LabelControl</controlname><Transformation>#htmlencode</Transformation></settings><properties><fieldcaption>{$newsletterissue.utm.source$}</fieldcaption><visiblemacro ismacro="true">{%IssueUseUTM%}</visiblemacro></properties></field><field allowempty="true" column="IssueUTMMedium" columnsize="200" columntype="text" dummy="altform" guid="1a0ce2e0-9178-4aa8-af6f-bf3e9d9243db" publicfield="false" system="true" visible="true" order="9"><properties><defaultvalue>email</defaultvalue><fieldcaption>{$newsletterissue.utm.medium$}</fieldcaption><visiblemacro ismacro="true">{%IssueUseUTM%}</visiblemacro></properties><settings><controlname>LabelControl</controlname><Transformation>#htmlencode</Transformation></settings></field><field column="IssueUTMCampaign" order="10"><settings><controlname>LabelControl</controlname></settings><properties><fieldcaption>{$newsletterissue.utm.campaign$}</fieldcaption><visiblemacro ismacro="true">{%IssueUseUTM%}</visiblemacro></properties></field><field column="IssueText" visible="" order="11" /><field column="IssueUnsubscribed" visible="" order="12" /><field column="IssueNewsletterID" visible="" order="13" /><field column="IssueTemplateID" visible="" order="14" /><field column="IssueSentEmails" visible="" order="15" /><field column="IssueShowInNewsletterArchive" visible="" order="16" /><field column="IssueGUID" visible="" order="17"><settings><controlname>UploadControl</controlname><Extensions>inherit</Extensions></settings></field><field column="IssueLastModified" visible="" order="18" /><field column="IssueSiteID" visible="" order="19" /><field column="IssueOpenedEmails" visible="" order="20" /><field column="IssueBounces" visible="" order="21" /><field column="IssueVariantOfIssueID" visible="" order="22" /><field column="IssueScheduledTaskID" visible="" order="23" /><field column="IssueUseUTM" visible="" order="24"><properties><defaultvalue>False</defaultvalue></properties></field></form>'
  WHERE [FormGUID] = '34AD0618-4CD7-44C0-8D57-AB32EDEC95A9'

END
GO


-- HF9-76 - Top landing pages - Weekly report is showing wrong data (for page views)
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 2
BEGIN
	UPDATE [Reporting_Report]
	SET [ReportParameters] = '<form version="2"><field column="FromDate" columntype="datetime" guid="adf581b8-eec1-46ad-ba0a-f7290add200a" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime.AddWeeks(-15).Date%}</defaultvalue><fieldcaption>{$general.from$}</fieldcaption></properties><settings><controlname>calendarcontrol</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="ToDate" columntype="datetime" guid="70aa642a-6385-4739-8a7b-e5d9e15d2df4" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><defaultvalue ismacro="true">{%CurrentDateTime%}</defaultvalue><fieldcaption>{$general.to$}</fieldcaption></properties><settings><controlname>calendarcontrol</controlname><DisplayNow>True</DisplayNow><EditTime>False</EditTime><TimeZoneType>inherit</TimeZoneType></settings></field><field column="CodeName" columnsize="50" columntype="text" guid="00000000-0000-0000-0000-000000000000" publicfield="false" reftype="Required" spellcheck="false"><properties><defaultvalue>landingpage</defaultvalue><fieldcaption>Code Name</fieldcaption></properties><settings><controlname>dropdownlistcontrol</controlname><query>SELECT DISTINCT StatisticsCode, StatisticsCode FROM Analytics_Statistics</query></settings></field></form>'
	WHERE [ReportGUID] = '5B4C69DC-5A1E-4FAF-9A65-81F2FF5714FB'
END
GO


-- HF9-92 - remove analytics page in Pages application when campaign module is not available
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 3
BEGIN
	UPDATE [CMS_UIElement] SET 
			[ElementDescription] = NULL, 
			[ElementFeature] = 'WebAnalytics', 
			[ElementIconClass] = '', 
			[ElementVisibilityCondition] = '{%System.IsModuleLoaded("CMS.WebAnalytics")%}'
	WHERE [ElementGUID] = 'f6413e96-fb74-40fa-bd7d-d987eee2ac3a'

	UPDATE [CMS_UIElement] SET 
			[ElementDescription] = NULL, 
			[ElementFeature] = 'CampaignAndConversions', 
			[ElementIconClass] = '', 
			[ElementVisibilityCondition] = '{%System.IsModuleLoaded("CMS.WebAnalytics")%}'
	WHERE [ElementGUID] = '993d8225-c9e9-48cd-ba70-d996d43155da'
END
GO


-- HF9-114 - "Check bounced emails" task doesn't update its status if external scheduler is used
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 5
BEGIN
	UPDATE [CMS_ScheduledTask] SET 
			[TaskUseExternalService] = 0 
	WHERE [TaskClass] = 'CMS.Newsletters.BounceChecker'
END
GO


-- HF9-190 - Web farm query missing in CMS_Query table
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 12
BEGIN
	DECLARE @classID int;
	SET @classID = (SELECT TOP 1 [ClassID] FROM [CMS_Class] WHERE [ClassName] = 'cms.WebFarmServer')
	IF @classID IS NOT NULL 
	BEGIN
		DELETE FROM [CMS_Query]
			WHERE [QueryGUID] = '0c066943-b46e-4ad4-aefe-30310be35a92' AND [ClassID] = @classID
	END
END
GO


-- HF9-218 - "Process analytics log" task can throw "file not found" error or cause a deadlock
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 14
BEGIN
	declare @alterScript NVARCHAR(MAX)
	select @alterScript =
'ALTER PROCEDURE [Proc_CMS_ScheduledTask_FetchTasksToRun]
	@TaskSiteID int,
	@DateTime datetime,
	@TaskServerName nvarchar(100),
	@UseExternalService bit = null
AS
BEGIN
	SET NOCOUNT ON;
	
	IF (@TaskSiteID IS NOT NULL)
    BEGIN
		/* Get tasks for specified site and global tasks that should be processed by application */
		IF (@UseExternalService = 0)
		BEGIN
			;WITH q AS
			(
				SELECT TaskID, TaskDisplayName, TaskNextRunTime, TaskExecutingServerName
					FROM CMS_ScheduledTask
					WHERE TaskNextRunTime IS NOT NULL AND TaskNextRunTime <= @DateTime AND TaskEnabled = 1
						AND (TaskSiteID = @TaskSiteID OR TaskSiteID IS NULL)
						AND (TaskServerName IS NULL OR TaskServerName = '''' OR TaskServerName = @TaskServerName)
						AND (TaskUseExternalService = 0 OR TaskUseExternalService IS NULL)
			)
			UPDATE q SET TaskNextRunTime = NULL, TaskExecutingServerName = @TaskServerName
				OUTPUT INSERTED.[TaskID], INSERTED.[TaskDisplayName];
		END
		ELSE IF (@UseExternalService = 1)
        /* Get tasks for specified site and global tasks that should be processed by external service */
        BEGIN
			;WITH q AS
			(
				SELECT TaskID, TaskDisplayName, TaskNextRunTime, TaskExecutingServerName
					FROM CMS_ScheduledTask
					WHERE TaskNextRunTime IS NOT NULL AND TaskNextRunTime <= @DateTime AND TaskEnabled = 1
						AND (TaskSiteID = @TaskSiteID OR TaskSiteID IS NULL)
						AND (TaskServerName IS NULL OR TaskServerName = '''' OR TaskServerName = @TaskServerName)
						AND (TaskUseExternalService = 1)
			)
			UPDATE q SET TaskNextRunTime = NULL, TaskExecutingServerName = @TaskServerName
				OUTPUT INSERTED.[TaskID], INSERTED.[TaskDisplayName];
        END
		ELSE IF (@UseExternalService IS NULL)
        /* Get tasks for specified site and global tasks */
        BEGIN
			;WITH q AS
			(
				SELECT TaskID, TaskDisplayName, TaskNextRunTime, TaskExecutingServerName
					FROM CMS_ScheduledTask
					WHERE TaskNextRunTime IS NOT NULL AND TaskNextRunTime <= @DateTime AND TaskEnabled = 1
						AND (TaskSiteID = @TaskSiteID OR TaskSiteID IS NULL)
						AND (TaskServerName IS NULL OR TaskServerName = '''' OR TaskServerName = @TaskServerName)
			)
			UPDATE q SET TaskNextRunTime = NULL, TaskExecutingServerName = @TaskServerName
				OUTPUT INSERTED.[TaskID], INSERTED.[TaskDisplayName];
        END
    END
    ELSE
    BEGIN
		IF (@UseExternalService = 1)
		/* Get sites and global tasks for external service (only for running sites) */
		BEGIN
			;WITH q AS
			(
				SELECT TaskID, TaskDisplayName, TaskNextRunTime, TaskExecutingServerName
					FROM CMS_ScheduledTask
					WHERE TaskNextRunTime IS NOT NULL AND TaskNextRunTime <= @DateTime AND TaskEnabled = 1
						AND (TaskSiteID IN (SELECT SiteID FROM CMS_Site WHERE SiteStatus = N''RUNNING'') OR TaskSiteID IS NULL)
						AND (TaskServerName IS NULL OR TaskServerName = '''' OR TaskServerName = @TaskServerName) 
						AND (TaskUseExternalService = 1)
			)
			UPDATE q SET TaskNextRunTime = NULL, TaskExecutingServerName = @TaskServerName
				OUTPUT INSERTED.[TaskID], INSERTED.[TaskDisplayName];
		END
		ELSE IF (@UseExternalService IS NULL)
		/* Get only global tasks if there is no site */
        BEGIN
			;WITH q AS
			(
				SELECT TaskID, TaskDisplayName, TaskNextRunTime, TaskExecutingServerName
					FROM CMS_ScheduledTask
					WHERE TaskNextRunTime IS NOT NULL AND TaskNextRunTime <= @DateTime AND TaskEnabled = 1 AND (TaskSiteID IS NULL)
						AND (TaskServerName IS NULL OR TaskServerName = '''' OR TaskServerName = @TaskServerName)
			)
			UPDATE q SET TaskNextRunTime = NULL, TaskExecutingServerName = @TaskServerName
				OUTPUT INSERTED.[TaskID], INSERTED.[TaskDisplayName];
        END
    END
END';

	exec(@alterScript)
END
GO

-- HF9-226 - Missing Editing form setting in page type
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 15
BEGIN

UPDATE [CMS_AlternativeForm]
  SET [FormDefinition] = '<form version="2"><category dummy="true" name="general.general" order="1"><properties><caption>{$general.general$}</caption><visible>True</visible></properties></category><field column="ClassDisplayName" order="2"><settings><controlname>localizabletextbox</controlname><ValueIsContent>False</ValueIsContent><AutoCompleteEnableCaching /><AutoCompleteFirstRowSelected /><AutoCompleteShowOnlyCurrentWordInCompletionListItem /><FilterMode /><Trim /></settings><properties><fielddescription>{$documenttype.classdisplayname.description$}</fielddescription></properties></field><field column="ClassName" order="3"><settings><ResourcePrefix>documenttype.edit</ResourcePrefix></settings><properties><fielddescription>{$documenttype.classname.description$}</fielddescription><validationerrormessage /></properties></field><field column="ClassUsesVersioning" order="4" /><field column="ClassIsDocumentType" order="5" /><field column="ClassIsCoupledClass" order="6" /><field column="ClassXmlSchema" order="7" /><field column="ClassFormDefinition" order="8" /><field column="ClassNodeNameSource" order="9" /><field column="ClassTableName" order="10"><settings><controlname>labelcontrol</controlname><AutoCompleteEnableCaching /><AutoCompleteFirstRowSelected /><AutoCompleteShowOnlyCurrentWordInCompletionListItem /><FilterMode /><Trim /></settings><properties><fielddescription>{$documenttype.classtablename.description$}</fielddescription><visiblemacro ismacro="true">{%ClassIsCoupledClass%}</visiblemacro></properties></field><field column="ClassURLPattern" visible="true" reftype="" order="11"><properties><fielddescription>{$documenttype.classurlpattern.description$}</fielddescription><visiblemacro ismacro="true">{%ClassIsContentOnly == true%}</visiblemacro></properties></field><field column="ClassInheritsFromClassID" visible="true" order="12"><settings><AddGlobalObjectNamePrefix>False</AddGlobalObjectNamePrefix><AddGlobalObjectSuffix>False</AddGlobalObjectSuffix><AllowAll>False</AllowAll><AllowDefault>False</AllowDefault><AllowEditTextBox>False</AllowEditTextBox><AllowEmpty>True</AllowEmpty><controlname>Uni_selector</controlname><DialogWindowName>SelectionDialog</DialogWindowName><DisplayNameFormat>{%ClassDisplayName%}</DisplayNameFormat><EditDialogWindowHeight>700</EditDialogWindowHeight><EditDialogWindowWidth>1000</EditDialogWindowWidth><EditWindowName>EditWindow</EditWindowName><EncodeOutput>True</EncodeOutput><GlobalObjectSuffix ismacro="true">{$general.global$}</GlobalObjectSuffix><ItemsPerPage>25</ItemsPerPage><LocalizeItems>True</LocalizeItems><MaxDisplayedItems>25</MaxDisplayedItems><MaxDisplayedTotalItems>50</MaxDisplayedTotalItems><ObjectType>cms.documenttype</ObjectType><RemoveMultipleCommas>False</RemoveMultipleCommas><ReturnColumnName>ClassID</ReturnColumnName><ReturnColumnType>id</ReturnColumnType><SelectionMode>1</SelectionMode><UseAutocomplete>False</UseAutocomplete><ValuesSeparator>;</ValuesSeparator><WhereCondition ismacro="true">ClassIsCoupledClass = 1 AND ClassID &lt;&gt; {%ClassID%} AND (ClassInheritsFromClassID IS NULL OR ClassInheritsFromClassID &lt;&gt; {%ClassID%})</WhereCondition></settings><properties><fieldcaption>{$DocumentType.InheritsFrom$}</fieldcaption><fielddescription>{$documenttype.classinheritsfromclassid.description$}</fielddescription><visiblemacro ismacro="true">{%ClassIsCoupledClass%}</visiblemacro></properties></field><field column="ClassIconClass" spellcheck="false" visible="true" order="13"><settings><controlname>documenttypeiconselector</controlname></settings><properties><fieldcaption>{$documenttype.icon$}</fieldcaption><fielddescription>{$documenttype.classicons.description$}</fielddescription></properties></field><field column="ClassResourceID" order="14"><settings><DisplayNone>True</DisplayNone><DisplayOnlyModulesInDevelopmentMode>True</DisplayOnlyModulesInDevelopmentMode></settings><properties><fieldcaption>{$pagetype.classresourceid$}</fieldcaption><fielddescription>{$pagetype.classresourceid.description$}</fielddescription></properties></field><category dummy="true" name="DocumentType.NewSettings" order="15"><properties><caption>{$DocumentType.NewSettings$}</caption><visible>True</visible></properties></category><field column="ClassNewPageUrl" visible="true" order="16"><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><FilterMode>False</FilterMode><Trim>False</Trim></settings><properties><fieldcaption>{$documenttype_edit_general.newpage$}</fieldcaption><fielddescription>{$documenttype.classnewpageurl.description$}</fielddescription></properties></field><field column="ClassShowTemplateSelection" hasdependingfields="true" visible="true" order="17"><settings><controlname>CheckBoxControl</controlname></settings><properties><fieldcaption>{$DocumentType_Edit_General.TemplateSelection$}</fieldcaption><fielddescription>{$documenttype.classshowtemplateselection.description$}</fielddescription><visiblemacro ismacro="true">{%!ClassIsContentOnly%}</visiblemacro></properties></field><field column="ClassPageTemplateCategoryID" dependsonanotherfield="true" hasdependingfields="true" visible="true" order="18"><settings><controlname>pagetemplatecategoryselector</controlname><ShowEmptyCategories>False</ShowEmptyCategories><WhereCondition>CategoryName != ''AdHoc'' AND CategoryPath NOT LIKE ''UITemplates%''</WhereCondition></settings><properties><fieldcaption>{$DocumentType_Edit_General.TemplateCategorySelection$}</fieldcaption><fielddescription>{$documenttype.classpagetemplatecategoryid.description$}</fielddescription><visiblemacro ismacro="true">{%ClassShowTemplateSelection%}</visiblemacro></properties></field><field column="ClassDefaultPageTemplateID" visible="true" order="19"><settings><controlname>selectpagetemplate</controlname><ReturnColumnName>PageTemplateID</ReturnColumnName><RootCategoryName>/</RootCategoryName><ShowOnlySiteTemplates>False</ShowOnlySiteTemplates><ShowTemplateButtons>False</ShowTemplateButtons><ShowTemplates>True</ShowTemplates></settings><properties><fieldcaption>{$DocumentType_Edit_General.DefaultTemplate$}</fieldcaption><fielddescription>{$documenttype.classdefaultpagetemplateid.description$}</fielddescription><visiblemacro ismacro="true">{%!ClassIsContentOnly%}</visiblemacro></properties></field><field column="ClassFormLayout" order="20" /><category dummy="true" name="DocumentType.EditingSettings" order="21"><properties><caption>{$DocumentType.EditingSettings$}</caption><visible>True</visible></properties></category><field column="ClassViewPageUrl" visible="true" order="22"><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><FilterMode>False</FilterMode><Trim>False</Trim></settings><properties><fieldcaption>{$DocumentType_Edit_General.ViewPage$}</fieldcaption><fielddescription>{$documenttype.classviewpageurl.description$}</fielddescription></properties></field><field column="ClassEditingPageUrl" reftype="Required" order="23"><settings><controlname>TextBoxControl</controlname><FilterMode>False</FilterMode></settings><properties><fieldcaption>{$DocumentType_Edit_General.EditingPage$}</fieldcaption><fielddescription>{$documenttype.classeditingpageurl.description$}</fielddescription><visiblemacro /></properties></field><field column="ClassPreviewPageUrl" visible="true" order="24"><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><FilterMode>False</FilterMode><Trim>False</Trim></settings><properties><fieldcaption>{$DocumentType_Edit_General.PreviewPage$}</fieldcaption><fielddescription>{$documenttype.classpreviewpageurl.description$}</fielddescription></properties></field><field column="ClassListPageUrl" visible="true" order="25"><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><FilterMode>False</FilterMode><Trim>False</Trim></settings><properties><fieldcaption>{$DocumentType_Edit_General.ListPage$}</fieldcaption><fielddescription>{$documenttype.classlistpageurl.description$}</fielddescription></properties></field><category dummy="true" name="documenttype.advanced" order="26"><properties><caption>{$documenttype.advanced$}</caption><visible>True</visible></properties></category><field column="ClassShowAsSystemTable" visible="" order="27" /><field column="ClassUsePublishFromTo" visible="true" order="28"><properties><fieldcaption>{$DocumentType_Edit_General.UsePublishFromTo$}</fieldcaption><fielddescription>{$documenttype.classusepublishfromto.description$}</fielddescription></properties></field><field column="ClassSKUMappings" order="29" /><field column="ClassIsMenuItemType" visible="true" order="30"><properties><fieldcaption>{$DocumentType_Edit_General.IsMenuItem$}</fieldcaption><fielddescription>{$documenttype.classismenuitemtype.description$}</fielddescription><validationerrormessage>{$sysdev.class_edit_gen.displayname$}</validationerrormessage></properties></field><field column="ClassNodeAliasSource" order="31" /><field column="ClassLastModified" order="32" /><field column="ClassGUID" order="33" /><field column="ClassCreateSKU" order="34" /><field column="ClassIsProduct" order="35" /><field column="ClassIsCustomTable" order="36" /><field column="ClassShowColumns" order="37" /><field column="ClassLoadGeneration" order="38"><properties><fielddescription>{$documenttype.classloadgeneration.description$}</fielddescription></properties></field><field column="ClassSearchTitleColumn" order="39" /><field column="ClassSearchContentColumn" order="40" /><field column="ClassSearchImageColumn" order="41" /><field column="ClassSearchCreationDateColumn" order="42" /><field column="ClassSearchSettings" order="43" /><field column="ClassConnectionString" visible="" order="44" /><field column="ClassSearchEnabled" order="45" /><field column="ClassSKUDefaultDepartmentName" order="46" /><field column="ClassSKUDefaultDepartmentID" order="47" /><field column="ClassContactMapping" order="48" /><field column="ClassContactOverwriteEnabled" order="49" /><field column="ClassSKUDefaultProductType" order="50" /><field column="ClassIsProductSection" order="51" /><field column="ClassFormLayoutType" order="52" /><field column="ClassVersionGUID" order="53" /><field column="ClassDefaultObjectType" order="54" /><field column="ClassIsForm" order="55" /><field column="ClassCustomizedColumns" order="56" /><field column="ClassCodeGenerationSettings" order="57" /><field column="ClassIsContentOnly" order="58" /></form>'
  WHERE [FormGUID] = 'F54A457D-25B5-4AB5-B13F-A35E9DF3F01A'

END
GO

-- HF9-282 - Removing a user from a site removed all of her group memberships from other sites as well
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 24
BEGIN
	declare @alterScript NVARCHAR(MAX)
	select @alterScript =
'ALTER PROCEDURE [Proc_CMS_User_RemoveSiteRoles]
	@UserID int,
	@SiteID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DELETE FROM [CMS_UserRole] WHERE
		UserID=@UserID AND
		RoleID IN (
			SELECT RoleID FROM [CMS_Role]
			WHERE [CMS_Role].[SiteID]=@SiteID
		);
	DELETE FROM [Community_GroupMember] WHERE
		MemberUserID=@UserID AND 
		MemberGroupID in (
			SELECT GroupID FROM [Community_Group] 
			WHERE GroupSiteID=@SiteID
		);
END';

exec(@alterScript)
END
GO


-- HF9-284 - Double forward slashes not saving in editor
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 24
BEGIN
	-- Update 'Rich text editor' definition
	UPDATE [CMS_FormUserControl]
	SET [UserControlParameters] = '<form version="2"><field allowempty="true" column="Width" columntype="integer" displayinsimplemode="true" guid="f793aac0-8380-438e-b7f3-7b3f7c1cfed0" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><fieldcaption>Width</fieldcaption><fielddescription>Sets the width of the editor area.</fielddescription><validationerrormessage>The value must be greater than 0.</validationerrormessage></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim></settings><rules><rule>{%Rule("Value &gt;= 1", "&lt;rules&gt;&lt;r pos=\"0\" par=\"\" op=\"and\" n=\"MinValue\" &gt;&lt;p n=\"minvalue\"&gt;&lt;t&gt;1&lt;/t&gt;&lt;v&gt;1&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;&lt;/d&gt;&lt;vt&gt;double&lt;/vt&gt;&lt;/p&gt;&lt;/r&gt;&lt;/rules&gt;")%}</rule></rules></field><field allowempty="true" column="WidthUnitType" columnsize="10" columntype="text" guid="1cb4ca25-94f0-4009-8c3a-9ab2f911965a" publicfield="false" visibility="none" visible="true"><properties><controlcssclass>ShortDropDownList</controlcssclass><fieldcaption>Width unit type</fieldcaption><fielddescription>Sets the width unit type of the editor area.</fielddescription></properties><settings><controlname>dropdownlistcontrol</controlname><EditText>False</EditText><Options>PX;px
EM;em
PERCENTAGE;%</Options></settings></field><field allowempty="true" column="Height" columntype="integer" displayinsimplemode="true" guid="f37fd7cf-18e4-4418-b13d-6adb23c46ad4" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><fieldcaption>Height</fieldcaption><fielddescription>Sets the height of the editor area.</fielddescription><validationerrormessage>The value must be greater than 0.</validationerrormessage></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim></settings><rules><rule>{%Rule("Value &gt;= 1", "&lt;rules&gt;&lt;r pos=\"0\" par=\"\" op=\"and\" n=\"MinValue\" &gt;&lt;p n=\"minvalue\"&gt;&lt;t&gt;1&lt;/t&gt;&lt;v&gt;1&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;&lt;/d&gt;&lt;vt&gt;double&lt;/vt&gt;&lt;/p&gt;&lt;/r&gt;&lt;/rules&gt;")%}</rule></rules></field><field allowempty="true" column="HeightUnitType" columnsize="10" columntype="text" guid="fb6f662c-71f9-4263-a2af-bf5283e8e64f" publicfield="false" visibility="none" visible="true"><properties><controlcssclass>ShortDropDownList</controlcssclass><fieldcaption>Height unit type</fieldcaption><fielddescription>Sets the height unit type of the editor area.</fielddescription></properties><settings><controlname>dropdownlistcontrol</controlname><EditText>False</EditText><Options>PX;px
EM;em
PERCENTAGE;%</Options></settings></field><field allowempty="true" column="Size" columntype="integer" displayinsimplemode="true" guid="5f9c0cb1-3cea-412b-8809-eadb44ce6998" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><fieldcaption>Maximum text length (without HTML tags)</fieldcaption><fielddescription>Sets the maximum length of the text that can be entered into the area. HTML tags are not counted towards the total length.</fielddescription><validationerrormessage>The value must be greater than 0.</validationerrormessage></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim></settings><rules><rule>{%Rule("Value &gt;= 1", "&lt;rules&gt;&lt;r pos=\"0\" par=\"\" op=\"and\" n=\"MinValue\" &gt;&lt;p n=\"minvalue\"&gt;&lt;t&gt;1&lt;/t&gt;&lt;v&gt;1&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;&lt;/d&gt;&lt;vt&gt;double&lt;/vt&gt;&lt;/p&gt;&lt;/r&gt;&lt;/rules&gt;")%}</rule></rules></field><field allowempty="true" column="CSSStylesheet" columnsize="250" columntype="text" guid="215f00e6-4f60-4d78-ad0d-c40b586a4537" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><fieldcaption>CSS stylesheet</fieldcaption><fielddescription>Selects the CSS stylesheet that should be applied to the editor.</fielddescription></properties><settings><AddDefaultRecord>True</AddDefaultRecord><controlname>cssstylesheetselector</controlname><SiteName>##ALL##</SiteName></settings></field><field allowempty="true" column="ToolbarSet" columnsize="250" columntype="text" guid="ad282e46-fa0b-47f6-939f-812a602aa62e" publicfield="false" resolvedefaultvalue="False" spellcheck="false" visibility="none" visible="true"><properties><fieldcaption>Toolbar set</fieldcaption><fielddescription>Specifies the toolbar set that should be used for the editor. Possible options:
Basic, BizForm, Default, Disabled, Forum, Group, Newsletter, Reporting, SimpleEdit, Standard, Widgets</fielddescription></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>TextBoxControl</controlname><FilterMode>False</FilterMode><Trim>False</Trim></settings></field><field allowempty="true" column="ToolbarLocation" columnsize="200" columntype="text" guid="b5f50a59-d8a4-403a-b4d9-4d7e285a837a" publicfield="false" resolvedefaultvalue="False" spellcheck="false" visibility="none" visible="true"><properties><fieldcaption>Toolbar location</fieldcaption><fielddescription>Sets the location of the toolbar editor. Possible options: In, Out, None, Default.</fielddescription></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>TextBoxControl</controlname><FilterMode>False</FilterMode><Trim>False</Trim></settings></field><field allowempty="true" column="StartingPath" columnsize="250" columntype="text" guid="1498a953-0d66-4db0-92cb-2e47b2c0ade2" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><fieldcaption>Starting path</fieldcaption><fielddescription>Specifies the starting paths for the dialogs available in the editor toolbar.</fielddescription></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim></settings></field><field allowempty="true" column="MediaDialogConfiguration" columntype="boolean" guid="6de63223-15fb-4a0f-9ce0-87d72d15b805" publicfield="false" spellcheck="false" visible="true"><properties><defaultvalue>true</defaultvalue><fieldcaption>Media dialog configuration</fieldcaption><fielddescription>Displays additonal configuration options for the advanced Insert Media dialog, which can be opened from the toolbar.</fielddescription><validationerrormessage>The value must be greater than 0.</validationerrormessage></properties><settings><controlname>mediadialogconfiguration</controlname><DisplayAnchorTabSettings>True</DisplayAnchorTabSettings><DisplayAutoresize>True</DisplayAutoresize><DisplayEmailTabSettings>True</DisplayEmailTabSettings><DisplayWebTabSettings>True</DisplayWebTabSettings></settings></field><field allowempty="true" column="ShowAddStampButton" columntype="boolean" guid="e9a26676-2726-4805-9137-54c98b3b4c47" publicfield="false" visibility="none" visible="true"><properties><defaultvalue>false</defaultvalue><fieldcaption>Show Add stamp button</fieldcaption><fielddescription>Shows Add stamp buttom under control</fielddescription><validationerrormessage>The value must be greater than 0.</validationerrormessage></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field allowempty="true" column="Autoresize" columnsize="10" columntype="text" guid="58e884c0-61c9-4aff-a5f1-f0654deb3755" publicfield="false" spellcheck="false"><properties><visiblemacro ismacro="true">{%false%}</visiblemacro></properties><settings><controlname>labelcontrol</controlname></settings></field><field allowempty="true" column="Autoresize_Width" columntype="integer" guid="f372245c-edf7-4ea9-8a50-bae90d73161c" publicfield="false" spellcheck="false"><properties><visiblemacro ismacro="true">{%false%}</visiblemacro></properties><settings><controlname>labelcontrol</controlname></settings></field><field allowempty="true" column="Autoresize_Height" columntype="integer" guid="942a6d7d-8505-440c-92a9-65864960dd5d" publicfield="false" spellcheck="false"><properties><visiblemacro ismacro="true">{%false%}</visiblemacro></properties><settings><controlname>labelcontrol</controlname></settings></field><field allowempty="true" column="Autoresize_MaxSideSize" columntype="integer" guid="9b9dc6b9-62b5-4fad-a4a4-1d19c59f0611" publicfield="false" spellcheck="false"><properties><visiblemacro ismacro="true">{%false%}</visiblemacro></properties><settings><controlname>labelcontrol</controlname></settings></field><field allowempty="true" column="Autoresize_Hashtable" columntype="boolean" guid="7b74e766-ab80-401f-9e61-76940606da80" publicfield="false" spellcheck="false"><properties><defaultvalue>true</defaultvalue><visiblemacro ismacro="true">{%false%}</visiblemacro></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field allowempty="true" column="Dialogs_Content_Hide" columntype="boolean" guid="a5044082-c0f6-4672-85c5-c321d8cb3ca0" publicfield="false" spellcheck="false"><properties><defaultvalue>false</defaultvalue><visiblemacro ismacro="true">{%false%}</visiblemacro></properties><settings><controlname>labelcontrol</controlname></settings></field><field allowempty="true" column="Dialogs_Content_Path" columnsize="250" columntype="text" guid="d7bf3e11-7f3f-406d-9ddc-aea8ec2353b2" publicfield="false" spellcheck="false"><properties><visiblemacro ismacro="true">{%false%}</visiblemacro></properties><settings><controlname>labelcontrol</controlname></settings></field><field allowempty="true" column="Dialogs_Content_Site" columnsize="250" columntype="text" guid="fa5cfacc-6fe5-42f2-a508-2a77870de812" publicfield="false" spellcheck="false"><properties><visiblemacro ismacro="true">{%false%}</visiblemacro></properties><settings><controlname>labelcontrol</controlname></settings></field><field allowempty="true" column="Dialogs_Content_UseRelativeURL" columntype="boolean" guid="b5d75ade-b438-41dd-b34d-aaf618a816db" publicfield="false" reftype="Required" resolvedefaultvalue="False"><properties><defaultvalue>true</defaultvalue></properties></field><field allowempty="true" column="Dialogs_Libraries_Hide" columntype="boolean" guid="0974c6d5-2d7a-45b7-bf79-8a9e30cd76ab" publicfield="false" spellcheck="false"><properties><defaultvalue>false</defaultvalue><visiblemacro ismacro="true">{%false%}</visiblemacro></properties><settings><controlname>labelcontrol</controlname></settings></field><field allowempty="true" column="Dialogs_Libraries_Site" columnsize="250" columntype="text" guid="5f24b1a7-9d8b-46fc-9492-699ed95dd2bd" publicfield="false" spellcheck="false"><properties><visiblemacro ismacro="true">{%false%}</visiblemacro></properties><settings><controlname>labelcontrol</controlname></settings></field><field allowempty="true" column="Dialogs_Libraries_Global" columnsize="250" columntype="text" guid="b54b7f2d-f3ec-4f40-930a-2ec268530a6f" publicfield="false" spellcheck="false"><properties><visiblemacro ismacro="true">{%false%}</visiblemacro></properties><settings><controlname>labelcontrol</controlname></settings></field><field allowempty="true" column="Dialogs_Libraries_Global_Libname" columnsize="250" columntype="text" guid="2e5db71e-509e-4488-bc77-6c5ce2d2492a" publicfield="false" spellcheck="false"><properties><visiblemacro ismacro="true">{%false%}</visiblemacro></properties><settings><controlname>labelcontrol</controlname></settings></field><field allowempty="true" column="Dialogs_Groups" columnsize="250" columntype="text" guid="f8d3f559-9974-42e1-97d7-648a2bba173d" publicfield="false" spellcheck="false"><properties><visiblemacro ismacro="true">{%false%}</visiblemacro></properties><settings><controlname>labelcontrol</controlname></settings></field><field allowempty="true" column="Dialogs_Groups_Name" columnsize="250" columntype="text" guid="70204fc7-22e0-4ab7-a110-ae91053e976c" publicfield="false" spellcheck="false"><properties><visiblemacro ismacro="true">{%false%}</visiblemacro></properties><settings><controlname>labelcontrol</controlname></settings></field><field allowempty="true" column="Dialogs_Libraries_Group" columnsize="250" columntype="text" guid="ff4b347e-5a3b-4a5a-8f04-073244cf48c6" publicfield="false" spellcheck="false"><properties><visiblemacro ismacro="true">{%false%}</visiblemacro></properties><settings><controlname>labelcontrol</controlname></settings></field><field allowempty="true" column="Dialogs_Libraries_Group_LibName" columnsize="250" columntype="text" guid="af1158c6-ec40-4a5b-b85f-6d37800a8652" publicfield="false" spellcheck="false"><properties><visiblemacro ismacro="true">{%false%}</visiblemacro></properties><settings><controlname>labelcontrol</controlname></settings></field><field allowempty="true" column="Dialogs_Libraries_Path" columnsize="250" columntype="text" guid="77e49582-f4fa-4a8a-9737-eef335a697af" publicfield="false" spellcheck="false"><properties><visiblemacro ismacro="true">{%false%}</visiblemacro></properties><settings><controlname>labelcontrol</controlname></settings></field><field allowempty="true" column="Dialogs_Attachments_Hide" columntype="boolean" guid="a6666a2b-796f-409d-bce4-983354940b6e" publicfield="false" spellcheck="false"><properties><defaultvalue>false</defaultvalue><visiblemacro ismacro="true">{%false%}</visiblemacro></properties><settings><controlname>labelcontrol</controlname></settings></field><field allowempty="true" column="Dialogs_Anchor_Hide" columntype="boolean" guid="addb4e63-f89a-4c2c-bdaa-3cad3daeb476" publicfield="false" spellcheck="false"><properties><defaultvalue>false</defaultvalue><visiblemacro ismacro="true">{%false%}</visiblemacro></properties><settings><controlname>labelcontrol</controlname></settings></field><field allowempty="true" column="Dialogs_Email_Hide" columntype="boolean" guid="08bd0583-5381-4286-b165-7137d77a7056" publicfield="false" spellcheck="false"><properties><defaultvalue>false</defaultvalue><visiblemacro ismacro="true">{%false%}</visiblemacro></properties><settings><controlname>labelcontrol</controlname></settings></field><field allowempty="true" column="Dialogs_Web_Hide" columntype="boolean" guid="75c129d3-75fd-4909-a46a-4165c6e3d735" publicfield="false" spellcheck="false"><properties><defaultvalue>false</defaultvalue><visiblemacro ismacro="true">{%false%}</visiblemacro></properties><settings><controlname>labelcontrol</controlname></settings></field></form>'
	WHERE [UserControlGUID] = 'E72F604B-1DC1-4F82-B620-1E686E9E0E08'
	
	-- Update 'BBcode editor' definition
	UPDATE [CMS_FormUserControl]
	SET [UserControlParameters] = '<form version="2"><field allowempty="true" column="Cols" columntype="integer" displayinsimplemode="true" guid="54eceb1b-73bd-49ab-95f9-be822c28868d" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><fieldcaption>Columns</fieldcaption><fielddescription>Sets the number of columns (width in characters) for the text area displayed in the BBCode editor.</fielddescription><validationerrormessage>The value must be greater than 0.</validationerrormessage></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim></settings><rules><rule>{%Rule("Value &gt;= 1", "&lt;rules&gt;&lt;r pos=\"0\" par=\"\" op=\"and\" n=\"MinValue\" &gt;&lt;p n=\"minvalue\"&gt;&lt;t&gt;1&lt;/t&gt;&lt;v&gt;1&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;&lt;/d&gt;&lt;vt&gt;double&lt;/vt&gt;&lt;/p&gt;&lt;/r&gt;&lt;/rules&gt;")%}</rule></rules></field><field allowempty="true" column="Rows" columntype="integer" displayinsimplemode="true" guid="6d46c0ea-fdab-4a3c-9e49-fff256302161" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><fieldcaption>Rows</fieldcaption><fielddescription>Sets the number of rows for the text area displayed in the BBCode editor.</fielddescription><validationerrormessage>The value must be greater than 0.</validationerrormessage></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim></settings><rules><rule>{%Rule("Value &gt;= 1", "&lt;rules&gt;&lt;r pos=\"0\" par=\"\" op=\"and\" n=\"MinValue\" &gt;&lt;p n=\"minvalue\"&gt;&lt;t&gt;1&lt;/t&gt;&lt;v&gt;1&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;&lt;/d&gt;&lt;vt&gt;double&lt;/vt&gt;&lt;/p&gt;&lt;/r&gt;&lt;/rules&gt;")%}</rule></rules></field><field allowempty="true" column="Size" columntype="integer" displayinsimplemode="true" guid="5d80c73f-260f-4bff-9377-d9dd380321c3" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><fieldcaption>Size</fieldcaption><fielddescription>Maximum number of characters allowed in the BBCode editor.</fielddescription><validationerrormessage>The Size field must be greater than 0.</validationerrormessage></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim></settings><rules><rule>{%Rule("Value &gt;= 1", "&lt;rules&gt;&lt;r pos=\"0\" par=\"\" op=\"and\" n=\"MinValue\" &gt;&lt;p n=\"minvalue\"&gt;&lt;t&gt;1&lt;/t&gt;&lt;v&gt;1&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;&lt;/d&gt;&lt;vt&gt;double&lt;/vt&gt;&lt;/p&gt;&lt;/r&gt;&lt;/rules&gt;")%}</rule></rules></field><field allowempty="true" column="ShowImage" columntype="boolean" guid="b09af8e5-74a3-4d64-a09c-78233f5da037" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><defaultvalue>true</defaultvalue><fieldcaption>Show ''Insert image'' button</fieldcaption><fielddescription>Indicates if the button for inserting Image tags should be available on the toolbar.</fielddescription><validationerrormessage>The Size field must be greater than 0.</validationerrormessage></properties><settings><controlname>imagedialogselector</controlname></settings></field><field allowempty="true" column="ShowAdvancedImage" columntype="boolean" guid="74c7cfee-ef6a-439c-9100-13661c57f6ee" publicfield="false" spellcheck="false" visibility="none"><properties><defaultvalue>false</defaultvalue><fieldcaption>Show advanced  ''Insert image'' dialog</fieldcaption><fielddescription>Determines whether to display button for Image tag insertion  using advanced dialog.</fielddescription></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field allowempty="true" column="ShowUrl" columntype="boolean" guid="fffa3c72-8e52-4b74-84e6-2ccb542116e4" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><defaultvalue>true</defaultvalue><fieldcaption>Show ''Insert link'' button</fieldcaption><fielddescription>Indicates if the button for inserting URL tags (links) should be available on the toolbar.</fielddescription><validationerrormessage>The Size field must be greater than 0.</validationerrormessage></properties><settings><controlname>linkdialogselector</controlname></settings></field><field allowempty="true" column="ShowAdvancedUrl" columntype="boolean" guid="186cba99-cfcb-421a-a9d3-07cf118681be" publicfield="false" spellcheck="false" visibility="none"><properties><defaultvalue>false</defaultvalue><fieldcaption>Show advanced ''Insert link'' dialog</fieldcaption><fielddescription>Determines whether to display button for URL tag insertion using advanced dialog.</fielddescription></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field allowempty="true" column="ShowQuote" columntype="boolean" guid="a0585436-bad1-4b0e-962a-d485ade920d6" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><defaultvalue>true</defaultvalue><fieldcaption>Show ''Insert quote'' button</fieldcaption><fielddescription>Indicates if the button for inserting Quote tags should be available on the toolbar.</fielddescription><validationerrormessage>The Size field must be greater than 0.</validationerrormessage></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field allowempty="true" column="ShowCode" columntype="boolean" guid="068d3d29-84fd-43e9-bf06-b68c70a46384" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><defaultvalue>true</defaultvalue><fieldcaption>Show ''Insert code'' button</fieldcaption><fielddescription>Indicates if the button for inserting Code tags should be available on the toolbar.</fielddescription><validationerrormessage>The Size field must be greater than 0.</validationerrormessage></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field allowempty="true" column="ShowBold" columntype="boolean" guid="5a61cf4c-6321-4534-a2f7-0c5dce4b6108" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><defaultvalue>true</defaultvalue><fieldcaption>Show ''Bold'' button</fieldcaption><fielddescription>Indicates if the button for inserting Bold font style tags should be available on the toolbar.</fielddescription><validationerrormessage>The Size field must be greater than 0.</validationerrormessage></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field allowempty="true" column="ShowItalic" columntype="boolean" guid="632a7517-0754-4780-9128-6d01eb10c919" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><defaultvalue>true</defaultvalue><fieldcaption>Show ''Italics'' button</fieldcaption><fielddescription>Indicates if the button for inserting Italics font style tags should be available on the toolbar.</fielddescription><validationerrormessage>The Size field must be greater than 0.</validationerrormessage></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field allowempty="true" column="ShowUnderline" columntype="boolean" guid="d3251f1e-ccfc-42cf-8057-28c5b3000275" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><defaultvalue>true</defaultvalue><fieldcaption>Show ''Underline'' button</fieldcaption><fielddescription>Indicates if the button for inserting Underline font style tags should be available on the toolbar.</fielddescription><validationerrormessage>The Size field must be greater than 0.</validationerrormessage></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field allowempty="true" column="ShowStrike" columntype="boolean" guid="c3ad187b-786c-442b-9556-855a5427ac8e" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><defaultvalue>true</defaultvalue><fieldcaption>Show ''Strikethrough'' button</fieldcaption><fielddescription>Indicates if the button for inserting Strike-through font style tags should be available on the toolbar.</fielddescription><validationerrormessage>The Size field must be greater than 0.</validationerrormessage></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field allowempty="true" column="ShowColor" columntype="boolean" guid="7c2c5e3c-31b8-466b-87d1-ec6fbd1a3dbe" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><defaultvalue>true</defaultvalue><fieldcaption>Show ''Color'' button</fieldcaption><fielddescription>Indicates if the button for inserting Font color style tags should be available on the toolbar.</fielddescription><validationerrormessage>The Size field must be greater than 0.</validationerrormessage></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field allowempty="true" column="UsePromptDialog" columntype="boolean" guid="e8842f09-48d7-4d68-b5cf-b87aac8bddb2" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><defaultvalue>true</defaultvalue><fieldcaption>Use prompt dialog</fieldcaption><fielddescription>Determines whether a prompt dialog should be displayed when the Insert link/image and Font color buttons are clicked. The prompt dialog doesn''t work correctly if the BBCode editor is placed in a modal window.</fielddescription><validationerrormessage>The Size field must be greater than 0.</validationerrormessage></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field allowempty="true" column="MediaDialogConfiguration" columntype="boolean" guid="a8520189-c917-4bb4-bcad-49aa22d04595" publicfield="false" spellcheck="false" visibility="none" visible="true"><properties><defaultvalue>false</defaultvalue><fieldcaption>Media dialog configuration</fieldcaption><fielddescription>Displays additonal configuration options for the advanced Insert Media dialog.</fielddescription><validationerrormessage>The value must be greater than 0.</validationerrormessage></properties><settings><controlname>mediadialogconfiguration</controlname><DisplayAnchorTabSettings>True</DisplayAnchorTabSettings><DisplayAutoresize>True</DisplayAutoresize><DisplayEmailTabSettings>False</DisplayEmailTabSettings><DisplayWebTabSettings>True</DisplayWebTabSettings></settings></field><field allowempty="true" column="Autoresize" columnsize="10" columntype="text" guid="5d575f29-0d6a-453e-8aba-7cd9da08ca9b" publicfield="false" spellcheck="false" visibility="none"><settings><controlname>agerangeselector</controlname></settings></field><field allowempty="true" column="Autoresize_Width" columntype="integer" guid="59c0a5bd-3cdc-4d7c-8663-9c3816686567" publicfield="false" spellcheck="false" visibility="none"><settings><controlname>badgeselector</controlname></settings></field><field allowempty="true" column="Autoresize_Height" columntype="integer" guid="6ec4409f-42b8-4631-9f9b-4ac7b54efd12" publicfield="false" spellcheck="false" visibility="none"><settings><controlname>badgeselector</controlname></settings></field><field allowempty="true" column="Autoresize_MaxSideSize" columntype="integer" guid="65c2fdc1-ca9d-4727-b6fc-f2c9e36f16e6" publicfield="false" spellcheck="false" visibility="none"><settings><controlname>badgeselector</controlname></settings></field><field allowempty="true" column="Autoresize_Hashtable" columntype="boolean" guid="a8584ffc-902d-4c4e-a5ff-bf39f0cccfde" publicfield="false" spellcheck="false" visibility="none"><properties><defaultvalue>true</defaultvalue></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field allowempty="true" column="Dialogs_Content_Hide" columntype="boolean" guid="ecdda3c7-db6c-49a2-aa54-4fe940bd51fa" publicfield="false" spellcheck="false" visibility="none"><properties><defaultvalue>false</defaultvalue></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field allowempty="true" column="Dialogs_Content_Path" columnsize="250" columntype="text" guid="e6f18301-ea4b-48f2-bcc9-ddecfb1a32d5" publicfield="false" spellcheck="false" visibility="none"><settings><controlname>agerangeselector</controlname></settings></field><field allowempty="true" column="Dialogs_Content_Site" columnsize="250" columntype="text" guid="e13750bc-581f-4ae5-a733-6e4e9d715fb4" publicfield="false" spellcheck="false" visibility="none"><settings><controlname>agerangeselector</controlname></settings></field><field allowempty="true" column="Dialogs_Content_UseRelativeURL" columntype="boolean" guid="b7dd22cc-b599-4a6b-98ec-4f49c64de44e" publicfield="false" reftype="Required" resolvedefaultvalue="False"><properties><defaultvalue>true</defaultvalue></properties></field><field allowempty="true" column="Dialogs_Libraries_Hide" columntype="boolean" guid="7bb21bb9-2a45-411b-abf0-8599c22eeb42" publicfield="false" spellcheck="false" visibility="none"><properties><defaultvalue>false</defaultvalue></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field allowempty="true" column="Dialogs_Libraries_Site" columnsize="250" columntype="text" guid="df8a533f-12ec-4a79-8fd1-4e5c6b799b92" publicfield="false" spellcheck="false" visibility="none"><settings><controlname>agerangeselector</controlname></settings></field><field allowempty="true" column="Dialogs_Libraries_Global" columnsize="250" columntype="text" guid="5f49b092-973f-49c0-9966-aa7f0e2b620f" publicfield="false" spellcheck="false" visibility="none"><settings><controlname>agerangeselector</controlname></settings></field><field allowempty="true" column="Dialogs_Libraries_Global_Libname" columnsize="250" columntype="text" guid="aebdb7fc-4ad5-4fc8-b8dc-12a9dc894bb4" publicfield="false" spellcheck="false" visibility="none"><settings><controlname>agerangeselector</controlname></settings></field><field allowempty="true" column="Dialogs_Groups" columnsize="250" columntype="text" guid="2b7074c8-74ac-4537-8a17-d60916868946" publicfield="false" spellcheck="false" visibility="none"><settings><controlname>agerangeselector</controlname></settings></field><field allowempty="true" column="Dialogs_Groups_Name" columnsize="250" columntype="text" guid="0e9c7c0c-4296-4e61-a9c4-49172b7d1976" publicfield="false" spellcheck="false" visibility="none"><settings><controlname>agerangeselector</controlname></settings></field><field allowempty="true" column="Dialogs_Libraries_Group" columnsize="250" columntype="text" guid="4a900580-11f5-4ff0-8971-7d32ba28d239" publicfield="false" spellcheck="false" visibility="none"><settings><controlname>agerangeselector</controlname></settings></field><field allowempty="true" column="Dialogs_Libraries_Group_LibName" columnsize="250" columntype="text" guid="727c5174-84f8-4e88-9628-4721f360290d" publicfield="false" spellcheck="false" visibility="none"><settings><controlname>agerangeselector</controlname></settings></field><field allowempty="true" column="Dialogs_Libraries_Path" columnsize="250" columntype="text" guid="8480c0d4-7c60-4cc1-bf2d-4320cae91041" publicfield="false" spellcheck="false" visibility="none"><settings><controlname>agerangeselector</controlname></settings></field><field allowempty="true" column="Dialogs_Attachments_Hide" columntype="boolean" guid="653e083d-e53a-4a6d-8040-7a485455629b" publicfield="false" spellcheck="false" visibility="none"><properties><defaultvalue>false</defaultvalue></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field allowempty="true" column="Dialogs_Anchor_Hide" columntype="boolean" guid="14ef9c9e-3f62-40a2-a79b-7369ab3f2572" publicfield="false" spellcheck="false" visibility="none"><properties><defaultvalue>false</defaultvalue></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field allowempty="true" column="Dialogs_Email_Hide" columntype="boolean" guid="1da85415-f69f-49fd-b220-5ff1d85569c5" publicfield="false" spellcheck="false" visibility="none"><properties><defaultvalue>false</defaultvalue></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field allowempty="true" column="Dialogs_Web_Hide" columntype="boolean" guid="6134f84e-b9b3-4020-9076-64216d2a65bf" publicfield="false" spellcheck="false" visibility="none"><properties><defaultvalue>false</defaultvalue></properties><settings><controlname>checkboxcontrol</controlname></settings></field></form>'
	WHERE [UserControlGUID] = '171698B7-DADC-4476-83FC-92F4766442C1'
END

GO


-- HF9-301 - Smart search index build failing
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 27
BEGIN
	UPDATE [CMS_Class] 
	SET [ClassFormDefinition] = '<form version="2"><field column="SearchTaskID" columntype="integer" guid="2d7ca691-6e80-4ab6-88ac-7609f9fc216f" isPK="true" isunique="true" publicfield="false" system="true"><properties><fieldcaption>SearchTaskID</fieldcaption></properties><settings><controlname>labelcontrol</controlname></settings></field><field column="SearchTaskType" columnsize="100" columntype="text" guid="851b8b0b-5aad-49d3-9d01-12dadd8c2bd4" publicfield="false" system="true"><properties><fieldcaption>SearchTaskType</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><field allowempty="true" column="SearchTaskObjectType" columnsize="100" columntype="text" guid="db90abf1-a656-4c80-a617-48ebc9f056b5" publicfield="false" system="true"><properties><fieldcaption>SearchTaskObjectType</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><field allowempty="true" column="SearchTaskField" columnsize="200" columntype="text" guid="2deab677-b15a-4540-94d5-3a35d17d66ef" publicfield="false" system="true"><properties><fieldcaption>SearchTaskField</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><field column="SearchTaskValue" columnsize="600" columntype="text" guid="91d12388-cfbb-42ec-9504-d46641293e97" publicfield="false" system="true" visibility="none"><properties><fieldcaption>SearchTaskValue</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><field allowempty="true" column="SearchTaskRelatedObjectID" columntype="integer" guid="cdce4162-bed3-42ff-84e5-b45e05314770" publicfield="false" system="true" /><field allowempty="true" column="SearchTaskServerName" columnsize="200" columntype="text" guid="178cb9b9-eb79-471e-ab7e-22ce39b8d02d" publicfield="false" system="true"><properties><fieldcaption>SearchTaskServerName</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><field column="SearchTaskStatus" columnsize="100" columntype="text" guid="fada5670-c89f-4799-b985-f918efeb9531" publicfield="false" system="true"><properties><fieldcaption>SearchTaskStatus</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><field column="SearchTaskPriority" columntype="integer" guid="9fea0ebb-8c50-415b-af7e-79b0a0310fa8" publicfield="false" reftype="Required" system="true" /><field allowempty="true" column="SearchTaskErrorMessage" columntype="longtext" guid="c62f6644-5b7b-4c62-9cf0-b694114ea708" publicfield="false" system="true"><properties><fieldcaption>Error Message</fieldcaption></properties><settings><Autoresize_Hashtable>True</Autoresize_Hashtable><controlname>htmlareacontrol</controlname><Dialogs_Content_Hide>False</Dialogs_Content_Hide><HeightUnitType>PX</HeightUnitType><MediaDialogConfiguration>True</MediaDialogConfiguration><ShowAddStampButton>False</ShowAddStampButton><WidthUnitType>PX</WidthUnitType></settings></field><field column="SearchTaskCreated" columntype="datetime" guid="1d560e5a-d4bb-4aa1-9a9a-3766244f444a" publicfield="false" system="true" visibility="none"><settings><controlname>labelcontrol</controlname><timezonetype>inherit</timezonetype></settings></field></form>'
    WHERE [ClassGUID] = '3ff254fe-d4de-4ad9-a6c9-cb71fc96c684' AND [ClassInheritsFromClassID] IS NULL

	IF NOT EXISTS (SELECT TOP 1 name
            FROM    syscolumns
            WHERE   id = OBJECT_ID('CMS_SearchTask')
                    AND name = 'SearchTaskPriority')
	BEGIN
		ALTER TABLE [CMS_SearchTask] ADD [SearchTaskPriority] int NOT NULL DEFAULT 0

		CREATE CLUSTERED INDEX [IX_CMS_SearchTask_SearchTaskPriority_SearchTaskStatus_SearchTaskServerName] ON [dbo].[CMS_SearchTask]
		(
			[SearchTaskPriority] DESC,
			[SearchTaskStatus] ASC,
			[SearchTaskServerName] ASC
		)
	END
END
GO

-- HF9-319 - Conversion calculation discrepancy in MVT reporting
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 29
BEGIN
	UPDATE Reporting_ReportTable
	SET TableQuery = 'SET @FromDate ={%DatabaseSchema%}.Func_Analytics_DateTrim(@FromDate,''year'');
	SET @ToDate ={%DatabaseSchema%}.Func_Analytics_EndDateTrim(@ToDate,''year'');

	SELECT X.Name AS ''{$mvtcombination.name$}'',ISNULL (SUM(Y.Hits),0) AS ''{$om.selectedperiod$}'',
	ISNULL(SUM(X.Hits),0) AS ''{$om.total$}''
	  FROM 
	(
	SELECT 
	   CASE
		  WHEN MVTCombinationCustomName  IS NULL OR MVTCombinationCustomName='''' THEN MVTCombinationName
		  ELSE MVTCombinationCustomName
		END   
		AS Name,MVTCombinationName, ISNULL(SUM (HitsCount),0) AS Hits,StatisticsObjectCulture
	 FROM Analytics_Statistics
	 INNER JOIN OM_MVTCombination ON 
	  MVTCombinationPageTemplateID IN ( SELECT 
	   CASE 
		WHEN [NodeTemplateForAllCultures] = 1 AND NodeTemplateID <> 0  THEN NodeTemplateID
		ELSE [DocumentPageTemplateID]
	   END   
	  FROM View_CMS_Tree_Joined WHERE NodeSiteID = @CMSContextCurrentSiteID
			AND NodeAliasPath IN(SELECT MVTestPage FROM OM_MVTest WHERE MVTestName = @MVTestName AND MVTestSiteID = @CMSContextCurrentSiteID)                        
			AND DocumentCulture = StatisticsObjectCulture)   
	  LEFT JOIN Analytics_YearHits ON StatisticsID = HitsStatisticsID

	 WHERE   (StatisticsSiteID = @CMSContextCurrentSiteID ) AND StatisticsCode LIKE ''mvtconversion;'' + @MVTestName + ''%''
	 AND MVTCombinationName = (SUBSTRING(StatisticsCode,LEN (''mvtconversion;''+@MVTestName+'';'')+1,LEN (StatisticsCode)))
	 AND ISNULL(@ConversionName,'''') IN ('''',StatisticsObjectName)
 
	 GROUP BY MVTCombinationName, StatisticsObjectCulture,
	   CASE
		  WHEN MVTCombinationCustomName  IS NULL OR MVTCombinationCustomName='''' THEN MVTCombinationName
		  ELSE MVTCombinationCustomName
		END
	) AS X 
	LEFT JOIN (SELECT SUBSTRING(StatisticsCode,LEN (''mvtconversion;''+@MVTestName+'';'')+1,LEN (StatisticsCode)) AS MVTCombinationName, SUM(HitsCount) AS Hits,
	StatisticsObjectCulture
	 FROM Analytics_Statistics JOIN Analytics_YearHits ON HitsStatisticsID = StatisticsID 
	 WHERE (StatisticsSiteID = @CMSContextCurrentSiteID) AND StatisticsCode LIKE ''mvtconversion;'' + @MVTestName + ''%''
	  AND (HitsStartTime >= @FromDate) AND (HitsEndTime <= @ToDate)   
	  AND ISNULL(@ConversionName,'''') IN ('''',StatisticsObjectName)
	  GROUP BY SUBSTRING(StatisticsCode,LEN (''mvtconversion;''+@MVTestName+'';'')+1,LEN (StatisticsCode)), StatisticsObjectCulture
	 )
	 AS Y ON X.MVTCombinationName = Y.MVTCombinationName AND X.StatisticsObjectCulture = Y.StatisticsObjectCulture
 
	 GROUP BY X.Name
	 ORDER BY [{$om.total$}] Desc'
	WHERE TableReportID = 663
END
GO

-- HF9-319 - Conversion calculation discrepancy in MVT reporting
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 29
BEGIN
	UPDATE Reporting_ReportTable
	SET TableQuery = 'SET @FromDate ={%DatabaseSchema%}.Func_Analytics_DateTrim(@FromDate,''week'');
	SET @ToDate ={%DatabaseSchema%}.Func_Analytics_EndDateTrim(@ToDate,''week'');

	SELECT X.Name AS ''{$mvtcombination.name$}'',ISNULL (SUM(Y.Hits),0) AS ''{$om.selectedperiod$}'',
	ISNULL(SUM(X.Hits),0) AS ''{$om.total$}''
	  FROM 
	(
	SELECT 
	   CASE
		  WHEN MVTCombinationCustomName  IS NULL OR MVTCombinationCustomName='''' THEN MVTCombinationName
		  ELSE MVTCombinationCustomName
		END   
		AS Name,MVTCombinationName, ISNULL(SUM (HitsCount),0) AS Hits,StatisticsObjectCulture
	 FROM Analytics_Statistics
	 INNER JOIN OM_MVTCombination ON 
	  MVTCombinationPageTemplateID IN ( SELECT 
	   CASE 
		WHEN [NodeTemplateForAllCultures] = 1 AND NodeTemplateID <> 0  THEN NodeTemplateID
		ELSE [DocumentPageTemplateID]
	   END   
	  FROM View_CMS_Tree_Joined WHERE NodeSiteID = @CMSContextCurrentSiteID
			AND NodeAliasPath IN(SELECT MVTestPage FROM OM_MVTest WHERE MVTestName = @MVTestName AND MVTestSiteID = @CMSContextCurrentSiteID)                        
			AND DocumentCulture = StatisticsObjectCulture)   
	  LEFT JOIN Analytics_WeekHits ON StatisticsID = HitsStatisticsID

	 WHERE   (StatisticsSiteID = @CMSContextCurrentSiteID ) AND StatisticsCode LIKE ''mvtconversion;'' + @MVTestName + ''%''
	 AND MVTCombinationName = (SUBSTRING(StatisticsCode,LEN (''mvtconversion;''+@MVTestName+'';'')+1,LEN (StatisticsCode)))
	 AND ISNULL(@ConversionName,'''') IN ('''',StatisticsObjectName)
 
	 GROUP BY MVTCombinationName, StatisticsObjectCulture,
	   CASE
		  WHEN MVTCombinationCustomName  IS NULL OR MVTCombinationCustomName='''' THEN MVTCombinationName
		  ELSE MVTCombinationCustomName
		END
	) AS X 
	LEFT JOIN (SELECT SUBSTRING(StatisticsCode,LEN (''mvtconversion;''+@MVTestName+'';'')+1,LEN (StatisticsCode)) AS MVTCombinationName, SUM(HitsCount) AS Hits,
	StatisticsObjectCulture
	 FROM Analytics_Statistics JOIN Analytics_WeekHits ON HitsStatisticsID = StatisticsID 
	 WHERE (StatisticsSiteID = @CMSContextCurrentSiteID) AND StatisticsCode LIKE ''mvtconversion;'' + @MVTestName + ''%''
	  AND (HitsStartTime >= @FromDate) AND (HitsEndTime <= @ToDate)   
	  AND ISNULL(@ConversionName,'''') IN ('''',StatisticsObjectName)
	  GROUP BY SUBSTRING(StatisticsCode,LEN (''mvtconversion;''+@MVTestName+'';'')+1,LEN (StatisticsCode)), StatisticsObjectCulture
	 )
	 AS Y ON X.MVTCombinationName = Y.MVTCombinationName AND X.StatisticsObjectCulture = Y.StatisticsObjectCulture
 
	 GROUP BY X.Name
	 ORDER BY [{$om.total$}] Desc'
	WHERE TableReportID = 664
END
GO

-- HF9-319 - Conversion calculation discrepancy in MVT reporting
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 29
BEGIN
	UPDATE Reporting_ReportTable
	SET TableQuery = 'SET @FromDate ={%DatabaseSchema%}.Func_Analytics_DateTrim(@FromDate,''month'');
	SET @ToDate ={%DatabaseSchema%}.Func_Analytics_EndDateTrim(@ToDate,''month'');

	SELECT X.Name AS ''{$mvtcombination.name$}'',ISNULL (SUM(Y.Hits),0) AS ''{$om.selectedperiod$}'',
	ISNULL(SUM(X.Hits),0) AS ''{$om.total$}''
	  FROM 
	(
	SELECT 
	   CASE
		  WHEN MVTCombinationCustomName  IS NULL OR MVTCombinationCustomName='''' THEN MVTCombinationName
		  ELSE MVTCombinationCustomName
		END   
		AS Name,MVTCombinationName, ISNULL(SUM (HitsCount),0) AS Hits,StatisticsObjectCulture
	 FROM Analytics_Statistics
	 INNER JOIN OM_MVTCombination ON 
	  MVTCombinationPageTemplateID IN ( SELECT 
	   CASE 
		WHEN [NodeTemplateForAllCultures] = 1 AND NodeTemplateID <> 0  THEN NodeTemplateID
		ELSE [DocumentPageTemplateID]
	   END   
	  FROM View_CMS_Tree_Joined WHERE NodeSiteID = @CMSContextCurrentSiteID
			AND NodeAliasPath IN(SELECT MVTestPage FROM OM_MVTest WHERE MVTestName = @MVTestName AND MVTestSiteID = @CMSContextCurrentSiteID)                        
			AND DocumentCulture = StatisticsObjectCulture)   
	  LEFT JOIN Analytics_MonthHits ON StatisticsID = HitsStatisticsID

	 WHERE   (StatisticsSiteID = @CMSContextCurrentSiteID ) AND StatisticsCode LIKE ''mvtconversion;'' + @MVTestName + ''%''
	 AND MVTCombinationName = (SUBSTRING(StatisticsCode,LEN (''mvtconversion;''+@MVTestName+'';'')+1,LEN (StatisticsCode)))
	 AND ISNULL(@ConversionName,'''') IN ('''',StatisticsObjectName)
 
	 GROUP BY MVTCombinationName, StatisticsObjectCulture,
	   CASE
		  WHEN MVTCombinationCustomName  IS NULL OR MVTCombinationCustomName='''' THEN MVTCombinationName
		  ELSE MVTCombinationCustomName
		END
	) AS X 
	LEFT JOIN (SELECT SUBSTRING(StatisticsCode,LEN (''mvtconversion;''+@MVTestName+'';'')+1,LEN (StatisticsCode)) AS MVTCombinationName, SUM(HitsCount) AS Hits,
	StatisticsObjectCulture
	 FROM Analytics_Statistics JOIN Analytics_MonthHits ON HitsStatisticsID = StatisticsID 
	 WHERE (StatisticsSiteID = @CMSContextCurrentSiteID) AND StatisticsCode LIKE ''mvtconversion;'' + @MVTestName + ''%'' 
	  AND (HitsStartTime >= @FromDate) AND (HitsEndTime <= @ToDate)   
	  AND ISNULL(@ConversionName,'''') IN ('''',StatisticsObjectName)
	  GROUP BY SUBSTRING(StatisticsCode,LEN (''mvtconversion;''+@MVTestName+'';'')+1,LEN (StatisticsCode)), StatisticsObjectCulture
	 )
	 AS Y ON X.MVTCombinationName = Y.MVTCombinationName AND X.StatisticsObjectCulture = Y.StatisticsObjectCulture
 
	 GROUP BY X.Name
	 ORDER BY [{$om.total$}] Desc'
	WHERE TableReportID = 665
END
GO

-- HF9-319 - Conversion calculation discrepancy in MVT reporting
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 29
BEGIN
	UPDATE Reporting_ReportTable
	SET TableQuery = 'SET @FromDate ={%DatabaseSchema%}.Func_Analytics_DateTrim(@FromDate,''hour'');
	SET @ToDate ={%DatabaseSchema%}.Func_Analytics_EndDateTrim(@ToDate,''hour'');

	SELECT X.Name AS ''{$mvtcombination.name$}'',ISNULL (SUM(Y.Hits),0) AS ''{$om.selectedperiod$}'',
	ISNULL(SUM(X.Hits),0) AS ''{$om.total$}''
	  FROM 
	(
	SELECT 
	   CASE
		  WHEN MVTCombinationCustomName  IS NULL OR MVTCombinationCustomName='''' THEN MVTCombinationName
		  ELSE MVTCombinationCustomName
		END   
		AS Name,MVTCombinationName, ISNULL(SUM (HitsCount),0) AS Hits,StatisticsObjectCulture
	 FROM Analytics_Statistics
	 INNER JOIN OM_MVTCombination ON 
	  MVTCombinationPageTemplateID IN ( SELECT 
	   CASE 
		WHEN [NodeTemplateForAllCultures] = 1 AND NodeTemplateID <> 0  THEN NodeTemplateID
		ELSE [DocumentPageTemplateID]
	   END   
	  FROM View_CMS_Tree_Joined WHERE NodeSiteID = @CMSContextCurrentSiteID
			AND NodeAliasPath IN(SELECT MVTestPage FROM OM_MVTest WHERE MVTestName = @MVTestName AND MVTestSiteID = @CMSContextCurrentSiteID)                        
			AND DocumentCulture = StatisticsObjectCulture)   
	  LEFT JOIN Analytics_HourHits ON StatisticsID = HitsStatisticsID

	 WHERE   (StatisticsSiteID = @CMSContextCurrentSiteID ) AND StatisticsCode LIKE ''mvtconversion;'' + @MVTestName + ''%''
	 AND MVTCombinationName = (SUBSTRING(StatisticsCode,LEN (''mvtconversion;''+@MVTestName+'';'')+1,LEN (StatisticsCode)))
	 AND ISNULL(@ConversionName,'''') IN ('''',StatisticsObjectName)
 
	 GROUP BY MVTCombinationName, StatisticsObjectCulture,
	   CASE
		  WHEN MVTCombinationCustomName  IS NULL OR MVTCombinationCustomName='''' THEN MVTCombinationName
		  ELSE MVTCombinationCustomName
		END
	) AS X 
	LEFT JOIN (SELECT SUBSTRING(StatisticsCode,LEN (''mvtconversion;''+@MVTestName+'';'')+1,LEN (StatisticsCode)) AS MVTCombinationName, SUM(HitsCount) AS Hits,
	StatisticsObjectCulture
	 FROM Analytics_Statistics JOIN Analytics_HourHits ON HitsStatisticsID = StatisticsID 
	 WHERE (StatisticsSiteID = @CMSContextCurrentSiteID) AND StatisticsCode LIKE ''mvtconversion;'' + @MVTestName + ''%''
	  AND (HitsStartTime >= @FromDate) AND (HitsEndTime <= @ToDate)   
	  AND ISNULL(@ConversionName,'''') IN ('''',StatisticsObjectName)
	  GROUP BY SUBSTRING(StatisticsCode,LEN (''mvtconversion;''+@MVTestName+'';'')+1,LEN (StatisticsCode)), StatisticsObjectCulture
	 )
	 AS Y ON X.MVTCombinationName = Y.MVTCombinationName AND X.StatisticsObjectCulture = Y.StatisticsObjectCulture
 
	 GROUP BY X.Name
	 ORDER BY [{$om.total$}] Desc'
	WHERE TableReportID = 666
END
GO

-- HF9-319 - Conversion calculation discrepancy in MVT reporting
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 29
BEGIN
	UPDATE Reporting_ReportTable
	SET TableQuery = 'SET @FromDate ={%DatabaseSchema%}.Func_Analytics_DateTrim(@FromDate,''day'');
	SET @ToDate ={%DatabaseSchema%}.Func_Analytics_EndDateTrim(@ToDate,''day'');

	SELECT X.Name AS ''{$mvtcombination.name$}'',ISNULL (SUM(Y.Hits),0) AS ''{$om.selectedperiod$}'',
	ISNULL(SUM(X.Hits),0) AS ''{$om.total$}''
	  FROM 
	(
	SELECT 
	   CASE
		  WHEN MVTCombinationCustomName  IS NULL OR MVTCombinationCustomName='''' THEN MVTCombinationName
		  ELSE MVTCombinationCustomName
		END   
		AS Name,MVTCombinationName, ISNULL(SUM (HitsCount),0) AS Hits,StatisticsObjectCulture
	 FROM Analytics_Statistics
	 INNER JOIN OM_MVTCombination ON 
	  MVTCombinationPageTemplateID IN ( SELECT 
	   CASE 
		WHEN [NodeTemplateForAllCultures] = 1 AND NodeTemplateID <> 0  THEN NodeTemplateID
		ELSE [DocumentPageTemplateID]
	   END   
	  FROM View_CMS_Tree_Joined WHERE NodeSiteID = @CMSContextCurrentSiteID
			AND NodeAliasPath IN(SELECT MVTestPage FROM OM_MVTest WHERE MVTestName = @MVTestName AND MVTestSiteID = @CMSContextCurrentSiteID)                        
			AND DocumentCulture = StatisticsObjectCulture)   
	  LEFT JOIN Analytics_DayHits ON StatisticsID = HitsStatisticsID

	 WHERE   (StatisticsSiteID = @CMSContextCurrentSiteID ) AND StatisticsCode LIKE ''mvtconversion;'' + @MVTestName + ''%'' 
	 AND MVTCombinationName = (SUBSTRING(StatisticsCode,LEN (''mvtconversion;''+@MVTestName+'';'')+1,LEN (StatisticsCode)))
	 AND ISNULL(@ConversionName,'''') IN ('''',StatisticsObjectName)
 
	 GROUP BY MVTCombinationName, StatisticsObjectCulture,
	   CASE
		  WHEN MVTCombinationCustomName  IS NULL OR MVTCombinationCustomName='''' THEN MVTCombinationName
		  ELSE MVTCombinationCustomName
		END
	) AS X 
	LEFT JOIN (SELECT SUBSTRING(StatisticsCode,LEN (''mvtconversion;''+@MVTestName+'';'')+1,LEN (StatisticsCode)) AS MVTCombinationName, SUM(HitsCount) AS Hits,
	StatisticsObjectCulture
	 FROM Analytics_Statistics JOIN Analytics_DayHits ON HitsStatisticsID = StatisticsID 
	 WHERE (StatisticsSiteID = @CMSContextCurrentSiteID) AND StatisticsCode LIKE ''mvtconversion;'' + @MVTestName + ''%'' 
	  AND (HitsStartTime >= @FromDate) AND (HitsEndTime <= @ToDate)   
	  AND ISNULL(@ConversionName,'''') IN ('''',StatisticsObjectName)
	  GROUP BY SUBSTRING(StatisticsCode,LEN (''mvtconversion;''+@MVTestName+'';'')+1,LEN (StatisticsCode)), StatisticsObjectCulture
	 )
	 AS Y ON X.MVTCombinationName = Y.MVTCombinationName AND X.StatisticsObjectCulture = Y.StatisticsObjectCulture
 
	 GROUP BY X.Name
	 ORDER BY [{$om.total$}] Desc'
	WHERE TableReportID = 668
END
GO

-- HF9-334 - Google Maps web parts - API key
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 32
BEGIN
	DECLARE @WebPartDefinitions TABLE(
		WebPartName NVARCHAR(MAX),
		WebPartDefinition xml
	);
	
	INSERT INTO @webPartDefinitions(WebPartName, WebPartDefinition)
		SELECT WebPartName, CONVERT(XML, WebPartProperties)
		FROM CMS_WebPart
		WHERE WebPartName IN ('BasicGoogleMaps', 'GoogleMaps', 'StaticGoogleMaps');
		
	DECLARE @WebPartName NVARCHAR(MAX);
	DECLARE @WebPartDefinition XML;
	 
	DECLARE @WebPartCursor CURSOR;
	 
	SET @WebPartCursor = CURSOR FOR
		SELECT WebPartName, WebPartDefinition
		FROM @WebPartDefinitions;
	 
	OPEN @WebPartCursor;
	FETCH NEXT FROM @WebPartCursor INTO @WebPartName, @WebPartDefinition;
	 
	WHILE @@FETCH_STATUS = 0
	BEGIN
		DECLARE @guid NVARCHAR(MAX)
		SET @guid = CONVERT(nvarchar(MAX),NEWID());
	
		SET @WebPartDefinition.modify('insert
	<field allowempty="true" column="ApiKey" columnsize="200" columntype="text" guid="{sql:variable("@guid")}" publicfield="false" visibility="none" visible="true">
	    <properties>
	      <fieldcaption>API Key</fieldcaption>
	      <fielddescription>API key for communicating with Google services.</fielddescription>
	    </properties>
	    <settings>
	      <controlname>textboxcontrol</controlname>
	    </settings>
	</field>          
	as first         
	into (/form)[1]');
	
		UPDATE CMS_WebPart SET WebPartProperties = CONVERT(NVARCHAR(MAX), @WebPartDefinition) WHERE  WebPartName = @WebPartName;  
		FETCH NEXT FROM @WebPartCursor INTO @WebPartName, @WebPartDefinition;
	END
	 
	CLOSE @WebPartCursor;
	DEALLOCATE @WebPartCursor;
END
GO

-- HF9-341 - Required "separator" property prevents re-saving of multiple choise control in field editor
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 33
BEGIN
	DECLARE @formDefinition xml;
	DECLARE @exists bit;

	-- Update 'Multiple choise' definition
	-- Store current parameters definition of Multiple choice form control
	SELECT @formDefinition = [UserControlParameters] FROM [CMS_FormUserControl] WHERE [UserControlGUID] = 'D162CAC6-9044-45E8-B0CD-928855F56485';

	-- Check existence if 'allowempty' attribute
	SET @exists = @formDefinition.exist('form/field[@column="Separator" and @allowempty="true"]');

	IF (@exists = 0)
	BEGIN
		-- Insert "allowempty" attribute
		SET @formDefinition.modify('insert attribute allowempty {"true"} into (/form/field[@column="Separator"])[1]');

		-- Update parameters definition of Multiple choice form control
		UPDATE [CMS_FormUserControl] SET [UserControlParameters] = CONVERT(nvarchar(max), @formDefinition) WHERE [UserControlGUID] = 'D162CAC6-9044-45E8-B0CD-928855F56485';
	END

	
	-- Update 'List box' definition
	-- Store current parameters definition of List box form control
	SELECT @formDefinition = [UserControlParameters] FROM [CMS_FormUserControl] WHERE [UserControlGUID] = '8C475810-DEB7-426A-BD23-9493100F8A2B';

	-- Check existence if 'allowempty' attribute
	SET @exists = @formDefinition.exist('form/field[@column="Separator" and @allowempty="true"]');

	IF (@exists = 0)
	BEGIN
		-- Insert "allowempty" attribute and remove validation rules
		SET @formDefinition.modify('insert attribute allowempty {"true"} into (/form/field[@column="Separator"])[1]');
		SET @formDefinition.modify('delete /form/field[@column="Separator"]/rules[1]');

		-- Update parameters definition of List Box form control
		UPDATE [CMS_FormUserControl] SET [UserControlParameters] = CONVERT(nvarchar(max), @formDefinition) WHERE [UserControlGUID] = '8C475810-DEB7-426A-BD23-9493100F8A2B';
	END
END

GO
/* ----------------------------------------------------------------------------*/
/* This SQL command must be at the end and must contain current hotfix version */
/* ----------------------------------------------------------------------------*/
UPDATE [CMS_SettingsKey] SET KeyValue = '47' WHERE KeyName = N'CMSHotfixVersion'
GO
