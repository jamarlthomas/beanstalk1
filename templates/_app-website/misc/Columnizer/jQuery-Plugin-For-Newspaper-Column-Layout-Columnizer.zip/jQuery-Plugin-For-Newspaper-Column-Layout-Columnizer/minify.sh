rm src/jquery.columnizer.min.js
php tools/compress.php
echo "wrote src/jquery.columnizer.min.js"
